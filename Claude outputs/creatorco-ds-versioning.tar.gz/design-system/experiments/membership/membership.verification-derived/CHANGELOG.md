# Changelog — membership.verification-derived

## 0.1.0 — 2026-10-03

- Created against v2.0.0 (status: proposed).
- Changes `src/components/creatorco/verification.tsx`.
- Preview (`preview.html`, `before-after.png`) generated with `ds.mjs preview`.
