# Preview viewer (dev-only)

Builds the artifact previews from the **real components**, so a card can never drift from the code.

```sh
node design-system/viewer/build.mjs
```

- `src/specimens.tsx` — one specimen per catalogue card, composed from `@/components/ui` and `@/components/creatorco` with demo-seed data. Specimens named `Proposed*` and the proposed `Screen*` compositions are labelled "Proposed — not adopted".
- `src/shims/` — stand-ins for `next/link` and `next/navigation` (the bundle runs outside Next).
- Output: `../components/bundle.js` (IIFE, global `CreatorCo`, React bundled in; `CreatorCo.mount("Button")`) and `../components/bundle.css` (Tailwind compile of `src/app/globals.css`).

Rebuild after changing tokens or components, then republish the design-system artifact. Not part of the app build; excluded from lint and typecheck. Turning this into `npm run design:preview` is proposal P-13.
