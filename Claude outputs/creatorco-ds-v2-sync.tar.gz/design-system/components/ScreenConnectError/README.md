# ScreenConnectError

Connect — error — screenshot of the running app (Stage 07 build, demo seed). Validation error.

Mobile is iPhone width 390pt @2x; desktop is 1280px. Dark and light follow the page theme. Files: `screens/connect-error-{mobile|desktop}-{dark|light}.webp`.
