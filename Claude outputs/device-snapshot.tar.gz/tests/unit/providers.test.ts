import { describe, expect, it } from "vitest";

import { ADAPTERS, adaptersFor, findAdapter } from "@/providers/catalog";
import { ProviderError, classifyProviderError, isProviderOutage, ProviderRoutingError } from "@/providers/errors";
import { createMockProviderRegistry } from "@/providers/registry";
import { PROVIDER_KINDS } from "@/providers/types";
import { encodeMockCode } from "@/providers/social/mock-social-data-provider";

describe("provider registry", () => {
  it("exposes every provider behind its interface, in mock mode", async () => {
    const p = createMockProviderRegistry();
    for (const provider of [p.social, p.identity, p.bureau, p.financialData, p.lender]) {
      expect(provider.descriptor.mode).toBe("mock");
      await expect(provider.health()).resolves.toMatchObject({ status: "ok" });
    }
  });

  it("mocks are deterministic", async () => {
    const a = createMockProviderRegistry();
    const b = createMockProviderRegistry();
    const asOf = new Date("2026-01-01T00:00:00Z");
    const input = { platform: "instagram", externalAccountId: "acc-1", asOf, months: 12 };
    const history = await a.social.fetchHistory(input);
    expect(history).toEqual(await b.social.fetchHistory(input));
    expect(history).toHaveLength(12);
    expect(history[11]!.capturedAt.toISOString()).toBe("2026-01-01T00:00:00.000Z");
    const bureau = (pan: string) => a.bureau.fetchSummary({ subjectRef: pan, consentReceiptId: "r1" });
    const { retrievedAt: _r1, ...first } = await bureau("ABCPE1234F");
    const { retrievedAt: _r2, ...second } = await b.bureau.fetchSummary({
      subjectRef: "ABCPE1234F",
      consentReceiptId: "r1",
    });
    expect(first).toEqual(second);
  });

  it("mock bureau outcomes are driven by the PAN digits", async () => {
    const { bureau } = createMockProviderRegistry();
    const get = (pan: string) => bureau.fetchSummary({ subjectRef: pan, consentReceiptId: "r" });
    expect(await get("ABCPE1230F")).toMatchObject({ scoreBand: "no_hit", activeTradelines: 0 });
    expect(await get("ABCPE1238F")).toMatchObject({ scoreBand: "high", delinquentTradelines12m: 0, enquiries6m: 2 });
    expect(await get("ABCPE1295F")).toMatchObject({ scoreBand: "medium", delinquentTradelines12m: 1 });
    await expect(get("not-a-pan")).rejects.toThrow();
  });

  it("mock Account Aggregator returns monthly totals ending before the anchor month", async () => {
    const { financialData } = createMockProviderRegistry();
    const asOf = new Date("2026-10-03T10:00:00Z");
    const { reference, redirectUrl } = await financialData.requestConsent({
      subjectRef: "u1",
      consentReceiptId: "r1",
      monthsRequested: 12,
      redirectUri: "https://app.test/cb",
      asOf,
    });
    expect(redirectUrl).toContain("/connect/aa-mock?reference=");
    const summary = await financialData.fetchSummary(reference);
    expect(summary.monthly).toHaveLength(12);
    expect(summary.monthly[0]!.month).toBe("2025-10");
    expect(summary.monthly[11]!.month).toBe("2026-09");
    const { retrievedAt: _a, ...again } = await financialData.fetchSummary(reference);
    const { retrievedAt: _b, ...once } = summary;
    expect(again).toEqual(once);
  });

  it("social connection round-trips through begin/complete", async () => {
    const { social } = createMockProviderRegistry();
    const { authorizationUrl } = await social.beginConnection({
      platform: "youtube",
      state: "s1",
      redirectUri: "https://app.test/cb",
    });
    expect(authorizationUrl).toContain("state=s1");
    const code = encodeMockCode({ platform: "youtube", handle: "maya.makes", nonce: "n" });
    const account = await social.completeConnection({ platform: "youtube", code });
    expect(account).toMatchObject({ platform: "youtube", handle: "maya.makes" });
    expect(account.externalAccountId).toMatch(/^mock-youtube-/);
    expect(await social.completeConnection({ platform: "youtube", code })).toEqual(account);
    await expect(social.completeConnection({ platform: "instagram", code })).rejects.toThrow();
  });

  it("the simulated RE applies a transparent policy and never claims to be real", async () => {
    const { lender } = createMockProviderRegistry();
    const proposal = {
      proposalId: "p1",
      applicationRef: "a1",
      modelVersion: "uw-v0",
      riskGrade: "B",
      recommendedExposure: 275_000,
      maxRecommendedExposure: 300_000,
      recommendedTenorMonths: 12,
      reasonCodes: [],
    };
    const { lenderReference } = await lender.submitProposal(proposal);
    const decision = await lender.getDecision(lenderReference, proposal);
    expect(lender.descriptor.mode).toBe("mock");
    expect(decision.outcome).toBe("modified");
    expect(decision.approvedExposure).toBe(200_000);
  });
});

describe("adapter catalog", () => {
  it("has a mock adapter for every capability, running only in mock mode", () => {
    for (const kind of PROVIDER_KINDS) {
      const mock = findAdapter(kind, "mock");
      expect(mock?.modes).toEqual(["mock"]);
      expect(adaptersFor(kind).length).toBeGreaterThan(0);
    }
    expect(ADAPTERS.every((a) => a.secrets.every((s) => /^[a-zA-Z]+$/.test(s)))).toBe(true);
  });

  it("settings are strict, so a pasted secret is rejected", () => {
    const mock = findAdapter("bureau", "mock")!;
    expect(mock.settings.safeParse({ timeoutMs: 2000, simulateOutage: true }).success).toBe(true);
    expect(mock.settings.safeParse({ apiKey: "sk_live" }).success).toBe(false);
    expect(mock.settings.safeParse({ timeoutMs: 10 }).success).toBe(false);
  });

  it("a simulated outage fails async calls as unavailable and reports down", async () => {
    const bureau = findAdapter("bureau", "mock")!.create({ settings: { simulateOutage: true }, secrets: {} });
    await expect(bureau.fetchSummary({ subjectRef: "ABCPE1236F", consentReceiptId: "r" })).rejects.toMatchObject({
      errorClass: "unavailable",
    });
    await expect(bureau.health()).resolves.toMatchObject({ status: "down" });
    const social = findAdapter("social", "mock")!.create({ settings: { simulateOutage: true }, secrets: {} });
    expect(social.supportedPlatforms().length).toBeGreaterThan(0);
  });

  it("classifies errors: unknown failures count as outages, rejections don't", () => {
    expect(classifyProviderError(new TypeError("fetch failed"))).toBe("unavailable");
    expect(classifyProviderError(new ProviderError("rejected", "bad code"))).toBe("rejected");
    expect(isProviderOutage(new ProviderRoutingError("paused", "bureau"))).toBe(true);
    expect(isProviderOutage(new ProviderError("rejected", "bad"))).toBe(false);
  });
});
