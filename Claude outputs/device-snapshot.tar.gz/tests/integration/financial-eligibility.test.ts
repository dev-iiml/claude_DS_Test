import { count, eq, sql } from "drizzle-orm";
import { describe, expect, it } from "vitest";

import {
  auditEvents,
  bureauSummaries,
  cashflowMonths,
  creatorProfiles,
  creditApplications,
  financialFeatureRuns,
  financialFeatures,
  identityLookupResults,
  providerRequests,
} from "@/db/schema";
import { CONSENT_KEYS, grantConsent, hasValidConsent } from "@/modules/consent";
import { CONSENT_DEFINITION_SEEDS, currentDefinitionSeed } from "@/modules/consent/definitions";
import {
  completeOnboarding,
  saveAboutStep,
  saveBusinessStep,
  saveInterestsStep,
  saveProfileStep,
} from "@/modules/creator-profile/onboarding-service";
import { aboutStepSchema, businessStepSchema, profileStepSchema } from "@/modules/creator-profile/schemas";
import {
  closeApplication,
  completeCashflowSharing,
  expireStaleApplications,
  getApplication,
  getFinancialCapacity,
  getOpenApplication,
  runBureauCheck,
  saveApplicationDetails,
  skipCashflow,
  startApplication,
  startCashflowSharing,
} from "@/modules/financial-eligibility/application-service";
import { applicationDetailsSchema } from "@/modules/financial-eligibility/schemas";
import { signUpCreator } from "@/modules/identity/auth/auth-service";
import { withdrawPurpose } from "@/modules/privacy";
import { MockCreditBureauProvider } from "@/providers/bureau/mock-credit-bureau-provider";
import { MockFinancialDataProvider } from "@/providers/financial-data/mock-financial-data-provider";

import { authDepsFor, connectTestDb, testEmail } from "../support/db";

const { db } = connectTestDb();
const auth = authDepsFor(db);
const FIN_CONSENT = currentDefinitionSeed(CONSENT_KEYS.financialEligibility)!.id;
const bureau = new MockCreditBureauProvider();
const financialData = new MockFinancialDataProvider();
const details = applicationDetailsSchema.parse({
  purpose: "equipment",
  requestedAmount: "2,00,000",
  declaredMonthlyIncome: "90,000",
  declaredMonthlyEmi: "5,000",
  incomeSources: ["brand_deals", "platform_payouts"],
});

async function member(label = "fin") {
  const r = await signUpCreator(auth, { email: testEmail(label), password: "a long enough passphrase" });
  if (!r.ok) throw new Error("signup failed");
  const userId = r.user.userId;
  await saveAboutStep(
    db,
    userId,
    aboutStepSchema.parse({
      legalName: "Neel Shah",
      displayName: "Neel Films",
      city: "Ahmedabad",
      state: "Gujarat",
      languages: ["gu"],
    }),
  );
  await saveProfileStep(
    db,
    userId,
    profileStepSchema.parse({
      primaryCreatorHandle: `neel.${label}.test`,
      categories: ["photography"],
      primaryCategory: "photography",
      creatorSince: "2019-03",
      platforms: ["youtube"],
    }),
  );
  await saveBusinessStep(
    db,
    userId,
    businessStepSchema.parse({ legalForm: "individual", gstStatus: "not_registered" }),
  );
  await saveInterestsStep(db, userId, {
    prInterest: false,
    preferredCategories: [],
    brandInterests: [],
    travelInterest: false,
  });
  await completeOnboarding(db, userId, {
    consentDefinitionId: CONSENT_DEFINITION_SEEDS.find((d) => d.key === CONSENT_KEYS.creatorProfile)!.id,
  });
  return userId;
}

/** A member with a check that has details and a bureau summary. */
async function checkedMember(label: string, pan = "ABCPE1238F") {
  const userId = await member(label);
  const app = await startApplication({ db }, { userId, consentDefinitionId: FIN_CONSENT, source: "settings" });
  await saveApplicationDetails({ db }, { userId, applicationId: app.id, details });
  await runBureauCheck({ db, bureau }, { userId, applicationId: app.id, pan });
  return { userId, applicationId: app.id };
}

async function shareBank(userId: string, applicationId: string, approved = true) {
  const { redirectUrl } = await startCashflowSharing(
    { db, financialData },
    { userId, applicationId, redirectUri: "http://localhost/cb" },
  );
  const reference = new URL(redirectUrl, "http://x").searchParams.get("reference")!;
  return completeCashflowSharing({ db, financialData }, { userId, reference, approved });
}

describe("regulated financial domain", () => {
  it("keeps financial tables in their own `fin` schema", async () => {
    const rows = await db.execute(
      sql`select table_name from information_schema.tables where table_schema = 'fin' order by table_name`,
    );
    expect(rows.map((r) => r.table_name)).toEqual([
      "bureau_summaries",
      "cashflow_months",
      "credit_applications",
      "financial_feature_runs",
      "financial_features",
      "fraud_checks",
      "fraud_flags",
      "underwriting_inputs",
      "underwriting_results",
      "underwriting_runs",
    ]);
  });
});

describe("starting a check", () => {
  it("needs a completed profile, records the consent and is idempotent while open", async () => {
    const draft = await signUpCreator(auth, { email: testEmail("draft"), password: "a long enough passphrase" });
    if (!draft.ok) throw new Error();
    await expect(
      startApplication({ db }, { userId: draft.user.userId, consentDefinitionId: FIN_CONSENT, source: "settings" }),
    ).rejects.toMatchObject({ code: "profile_inactive" });

    const userId = await member("start");
    const a = await startApplication({ db }, { userId, consentDefinitionId: FIN_CONSENT, source: "settings" });
    expect(a).toMatchObject({ status: "draft", bureauStatus: "not_started", cashflowStatus: "not_started" });
    expect(a.expiresAt.getTime() - a.createdAt.getTime()).toBe(90 * 86_400_000);
    expect(await hasValidConsent(db, userId, CONSENT_KEYS.financialEligibility)).toBe(true);
    const b = await startApplication({ db }, { userId, consentDefinitionId: FIN_CONSENT, source: "settings" });
    expect(b.id).toBe(a.id);
  });

  it("enforces step order", async () => {
    const userId = await member("order");
    const app = await startApplication({ db }, { userId, consentDefinitionId: FIN_CONSENT, source: "settings" });
    await expect(
      runBureauCheck({ db, bureau }, { userId, applicationId: app.id, pan: "ABCPE1238F" }),
    ).rejects.toMatchObject({
      code: "wrong_step",
    });
    await expect(
      startCashflowSharing({ db, financialData }, { userId, applicationId: app.id, redirectUri: "http://x/cb" }),
    ).rejects.toMatchObject({ code: "wrong_step" });
  });
});

describe("bureau check", () => {
  it("stores only a summary and a masked PAN — the full PAN appears nowhere", async () => {
    const { userId, applicationId } = await checkedMember("bureau");
    const [app] = await db.select().from(creditApplications).where(eq(creditApplications.id, applicationId));
    expect(app).toMatchObject({ panMasked: "XXXXX1238F", bureauStatus: "completed" });
    const [summary] = await db.select().from(bureauSummaries).where(eq(bureauSummaries.applicationId, applicationId));
    expect(summary).toMatchObject({ scoreBand: "high", delinquentTradelines12m: 0, enquiries6m: 2 });

    const dump = JSON.stringify([
      app,
      summary,
      await db.select().from(providerRequests).where(eq(providerRequests.userId, userId)),
      await db.select().from(auditEvents).where(eq(auditEvents.actorId, userId)),
    ]);
    expect(dump).not.toContain("ABCPE1238F");
  });

  it("must match the creator's verified PAN when there is one", async () => {
    const userId = await member("mismatch");
    const receipt = await grantConsent(db, {
      userId,
      key: CONSENT_KEYS.identityPrefill,
      consentDefinitionId: CONSENT_DEFINITION_SEEDS.find((d) => d.key === CONSENT_KEYS.identityPrefill)!.id,
      source: "onboarding",
    });
    await db.insert(identityLookupResults).values({
      userId,
      mobile: "9000000005",
      verifiedName: "Neel Shah",
      panMasked: "XXXXX4321Z",
      provider: "mock",
      consentReceiptId: receipt.id,
      fetchedAt: new Date(),
    });
    const app = await startApplication({ db }, { userId, consentDefinitionId: FIN_CONSENT, source: "settings" });
    await saveApplicationDetails({ db }, { userId, applicationId: app.id, details });
    await expect(
      runBureauCheck({ db, bureau }, { userId, applicationId: app.id, pan: "ABCPE1238F" }),
    ).rejects.toMatchObject({
      code: "pan_mismatch",
    });
    await runBureauCheck({ db, bureau }, { userId, applicationId: app.id, pan: "ABCPE4321Z" });
  });

  it("limits bureau checks to three per 30 days", async () => {
    const { userId, applicationId } = await checkedMember("limit");
    await runBureauCheck({ db, bureau }, { userId, applicationId, pan: "ABCPE1235F" });
    await runBureauCheck({ db, bureau }, { userId, applicationId, pan: "ABCPE1236F" });
    await expect(runBureauCheck({ db, bureau }, { userId, applicationId, pan: "ABCPE1237F" })).rejects.toMatchObject({
      code: "bureau_limit",
    });
  });
});

describe("bank data and Financial Capacity", () => {
  it("stores 12 monthly totals, computes a reproducible run and ignores replayed callbacks", async () => {
    const { userId, applicationId } = await checkedMember("bank");
    const ready = await shareBank(userId, applicationId);
    expect(ready).toMatchObject({ status: "inputs_ready", cashflowStatus: "completed" });
    expect(
      (await db.select({ n: count() }).from(cashflowMonths).where(eq(cashflowMonths.applicationId, applicationId)))[0]!
        .n,
    ).toBe(12);

    const capacity = await getFinancialCapacity(db, { userId, applicationId });
    expect(capacity!.engineVersion).toBe("fin-0.1.0");
    expect(capacity!.features).toHaveLength(15);
    expect(capacity!.features.find((f) => f.key === "bureau_score_band")!.value).toBe("high");
    expect(capacity!.features.find((f) => f.key === "avg_monthly_inflow_6m")!.value).toBeGreaterThan(0);

    // Replay of the same callback changes nothing.
    const [app] = await db.select().from(creditApplications).where(eq(creditApplications.id, applicationId));
    expect(app!.cashflowReference).toMatch(/^aa_/);
    await completeCashflowSharing(
      { db, financialData },
      { userId, reference: app!.cashflowReference!, approved: false },
    );
    expect((await getApplication(db, { userId, applicationId }))!.cashflowStatus).toBe("completed");

    // Editing details after inputs are ready recomputes into a new, separate run.
    await saveApplicationDetails({ db }, { userId, applicationId, details: { ...details, declaredMonthlyEmi: 9_000 } });
    expect(
      (
        await db
          .select({ n: count() })
          .from(financialFeatureRuns)
          .where(eq(financialFeatureRuns.applicationId, applicationId))
      )[0]!.n,
    ).toBe(2);
    expect((await getApplication(db, { userId, applicationId }))!.status).toBe("inputs_ready");

    // Runs are append-only.
    await expect(
      db
        .update(financialFeatureRuns)
        .set({ engineVersion: "x" })
        .where(eq(financialFeatureRuns.applicationId, applicationId)),
    ).rejects.toThrow();
  });

  it("a declined share waits for retry or skip; skipping completes without bank data", async () => {
    const { userId, applicationId } = await checkedMember("decline");
    const declined = await shareBank(userId, applicationId, false);
    expect(declined).toMatchObject({ status: "draft", cashflowStatus: "declined" });
    const skipped = await skipCashflow({ db }, { userId, applicationId });
    expect(skipped).toMatchObject({ status: "inputs_ready", cashflowStatus: "skipped" });
    const capacity = await getFinancialCapacity(db, { userId, applicationId });
    expect(capacity!.features.find((f) => f.key === "avg_monthly_inflow_6m")!.value).toBeNull();
    expect(capacity!.features.find((f) => f.key === "emi_to_income")!.value).toBeCloseTo(5_000 / 90_000, 4);
  });

  it("asks to share again if the Account Aggregator was switched mid-flow", async () => {
    const { userId, applicationId } = await checkedMember("aaswitch");
    const { redirectUrl } = await startCashflowSharing(
      { db, financialData },
      { userId, applicationId, redirectUri: "http://localhost/cb" },
    );
    const reference = new URL(redirectUrl, "http://x").searchParams.get("reference")!;
    const switched = new Proxy(financialData, {
      get: (t, p, r) => (p === "descriptor" ? { ...t.descriptor, key: "aa_b" } : Reflect.get(t, p, r)),
    });
    // While the issuing config can still serve, the return leg completes with it.
    const pinned = await checkedMember("aapinned");
    const started = await startCashflowSharing(
      { db, financialData },
      { userId: pinned.userId, applicationId: pinned.applicationId, redirectUri: "http://localhost/cb" },
    );
    const pinnedRef = new URL(started.redirectUrl, "http://x").searchParams.get("reference")!;
    await expect(
      completeCashflowSharing(
        { db, financialData: switched, financialDataFor: async (key) => (key === "mock" ? financialData : null) },
        { userId: pinned.userId, reference: pinnedRef, approved: true },
      ),
    ).resolves.toMatchObject({ status: "inputs_ready" });

    // When it can't, the creator is asked to share again.
    await expect(
      completeCashflowSharing(
        { db, financialData: switched, financialDataFor: async () => null },
        { userId, reference, approved: true },
      ),
    ).rejects.toMatchObject({ code: "provider_changed", applicationId });
    const [app] = await db.select().from(creditApplications).where(eq(creditApplications.id, applicationId));
    expect(app).toMatchObject({ cashflowStatus: "not_started", cashflowReference: null, cashflowProvider: null });
    // Sharing again with the current provider works.
    expect(await shareBank(userId, applicationId)).toMatchObject({ status: "inputs_ready" });
  });

  it("is visible only to its owner", async () => {
    const { applicationId } = await checkedMember("owner");
    const other = await member("other");
    expect(await getApplication(db, { userId: other, applicationId })).toBeNull();
    expect(await getFinancialCapacity(db, { userId: other, applicationId })).toBeNull();
    await expect(saveApplicationDetails({ db }, { userId: other, applicationId, details })).rejects.toMatchObject({
      code: "consent_required",
    });
  });
});

async function inputsLeft(applicationId: string) {
  const [b] = await db
    .select({ n: count() })
    .from(bureauSummaries)
    .where(eq(bureauSummaries.applicationId, applicationId));
  const [m] = await db
    .select({ n: count() })
    .from(cashflowMonths)
    .where(eq(cashflowMonths.applicationId, applicationId));
  const [f] = await db
    .select({ n: count() })
    .from(financialFeatures)
    .where(eq(financialFeatures.applicationId, applicationId));
  return b!.n + m!.n + f!.n;
}

describe("closing, expiry and withdrawal", () => {
  it("closing erases inputs and leaves a tombstone that can't be deleted", async () => {
    const { userId, applicationId } = await checkedMember("close");
    await shareBank(userId, applicationId);
    await closeApplication({ db }, { userId, applicationId });
    const [app] = await db.select().from(creditApplications).where(eq(creditApplications.id, applicationId));
    expect(app).toMatchObject({
      status: "withdrawn",
      requestedAmount: null,
      declaredMonthlyIncome: null,
      declaredMonthlyEmi: null,
      incomeSources: [],
      panMasked: null,
      cashflowReference: null,
    });
    expect(app!.inputsErasedAt).not.toBeNull();
    expect(await inputsLeft(applicationId)).toBe(0);
    await expect(db.delete(creditApplications).where(eq(creditApplications.id, applicationId))).rejects.toThrow();
    expect(await getOpenApplication({ db }, userId)).toBeNull();
  });

  it("expires unsent checks after 90 days and erases their inputs", async () => {
    const { userId, applicationId } = await checkedMember("expiry");
    const later = new Date(Date.now() + 91 * 86_400_000);
    expect(await expireStaleApplications({ db, now: later }, { userId })).toBe(1);
    const [app] = await db.select().from(creditApplications).where(eq(creditApplications.id, applicationId));
    expect(app).toMatchObject({ status: "expired", requestedAmount: null });
    expect(await inputsLeft(applicationId)).toBe(0);
  });

  it("withdrawing the consent closes the check and erases its inputs", async () => {
    const { userId, applicationId } = await checkedMember("withdraw");
    const result = await withdrawPurpose(
      { db },
      { userId, key: CONSENT_KEYS.financialEligibility, source: "settings" },
    );
    expect(result.effects).toEqual({ checks_closed: 1 });
    expect(result.erasures).toEqual([{ scope: "financial_inputs", status: "completed", holdReasons: [] }]);
    expect((await getApplication(db, { userId, applicationId }))!.status).toBe("withdrawn");
    expect(await inputsLeft(applicationId)).toBe(0);
    await expect(saveApplicationDetails({ db }, { userId, applicationId, details })).rejects.toMatchObject({
      code: "consent_required",
    });
  });

  it("defers erasure while a check is with a partner lender", async () => {
    const { userId, applicationId } = await checkedMember("hold");
    await shareBank(userId, applicationId);
    // Stage 12 will submit to a lender; simulate it here.
    await db.update(creditApplications).set({ status: "submitted" }).where(eq(creditApplications.id, applicationId));
    const result = await withdrawPurpose(
      { db },
      { userId, key: CONSENT_KEYS.financialEligibility, source: "settings" },
    );
    expect(result.erasures).toEqual([
      { scope: "financial_inputs", status: "deferred", holdReasons: ["credit_application_in_progress"] },
    ]);
    expect(await inputsLeft(applicationId)).toBeGreaterThan(0);
    const [profile] = await db
      .select({ status: creatorProfiles.profileStatus })
      .from(creatorProfiles)
      .where(eq(creatorProfiles.userId, userId));
    expect(profile!.status).toBe("completed");
  });
});
