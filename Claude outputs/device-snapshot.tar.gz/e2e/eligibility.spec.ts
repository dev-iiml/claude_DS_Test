import { expect, test, type Page } from "@playwright/test";

import { signIn } from "./helpers";

/** Seeded completed creator (see src/db/seed/demo.ts). */
const AAROHI = "aarohi.menon@creators.creatorco.test";

async function signInAsAarohi(page: Page) {
  await signIn(page, AAROHI);
  await expect(page).toHaveURL(/\/dashboard$/);
}

test.describe("financial eligibility (Stage 09)", () => {
  test.describe.configure({ mode: "serial" });

  test("consent → details → credit check → bank data → Financial Capacity", async ({ page }) => {
    await signInAsAarohi(page);
    await page.getByRole("link", { name: "Check financial eligibility" }).click();
    await expect(page.getByRole("heading", { level: 1, name: "Financial eligibility" })).toBeVisible();
    await page.getByRole("link", { name: "Check financial eligibility" }).click();

    // Consent
    await expect(page.getByRole("heading", { level: 1, name: "Before we start" })).toBeVisible();
    await expect(page.getByText("Financial eligibility check")).toBeVisible();
    await page.getByRole("button", { name: "Start my check" }).click();
    await expect(page.getByText("Tick the box to give this consent.").first()).toBeVisible();
    await page.getByRole("checkbox", { name: /I agree to CreatorCo checking my financial eligibility/ }).check();
    await page.getByRole("button", { name: "Start my check" }).click();

    // Details
    await expect(page).toHaveURL(/\/eligibility\/[0-9a-f-]+\/details$/);
    await page.getByRole("button", { name: "Save and continue" }).click();
    await expect(page.getByText("Please check the highlighted fields.")).toBeVisible();
    await page.getByRole("radio", { name: "Camera, studio or tech equipment" }).check();
    await page.getByLabel("Roughly how much?").fill("1,50,000");
    await page.getByLabel("Average monthly income").fill("85000");
    await page.getByRole("checkbox", { name: "Brand deals" }).check();
    await page.getByRole("checkbox", { name: "Platform payouts" }).check();
    await page.getByLabel("Existing monthly EMIs").fill("0");
    await page.getByRole("button", { name: "Save and continue" }).click();

    // Credit check — PAN is never echoed back
    await expect(page).toHaveURL(/\/credit-check$/);
    await page.getByLabel("Your PAN").fill("ABCCE1238F");
    await page.getByRole("checkbox", { name: /This is my PAN/ }).check();
    await page.getByRole("button", { name: "Run credit check" }).click();
    await expect(page.getByText(/personal PAN/).first()).toBeVisible();
    await expect(page.getByLabel("Your PAN")).toHaveValue("");
    await page.getByLabel("Your PAN").fill("abcpe1238f");
    await page.getByRole("checkbox", { name: /This is my PAN/ }).check();
    await page.getByRole("button", { name: "Run credit check" }).click();

    // Bank data via the mock Account Aggregator
    await expect(page).toHaveURL(/\/bank$/);
    await expect(page.getByText("Not individual transactions")).toBeVisible();
    await page.getByRole("button", { name: "Share via Account Aggregator" }).click();
    await expect(page).toHaveURL(/\/connect\/aa-mock\?/);
    await expect(page.getByText("Test Account Aggregator — simulated")).toBeVisible();
    await page.getByRole("button", { name: "Approve" }).click();

    // Financial Capacity
    await expect(page).toHaveURL(/\/eligibility\/[0-9a-f-]+$/);
    await expect(page.getByRole("heading", { level: 1, name: "Your Financial Capacity" })).toBeVisible();
    await expect(page.getByRole("region", { name: "Credit history" }).getByText("Strong")).toBeVisible();
    await expect(
      page.getByRole("region", { name: "Bank cashflow" }).getByText("Average money in each month"),
    ).toBeVisible();
    await expect(page.getByRole("region", { name: "Your request" }).getByText("₹1,50,000")).toBeVisible();
    await expect(
      page.getByRole("region", { name: "What happens next" }).getByText("Prepared", { exact: true }),
    ).toBeVisible();
    await expect(page.locator("main")).not.toContainText("ABCPE1238F");
    await expect(page.locator("main")).not.toContainText(/approved|you are eligible|limit of/i);

    // Home shows the check in progress.
    await page.goto("/dashboard");
    await expect(page.getByRole("link", { name: "Continue your check" })).toBeVisible();
  });

  test("closing a check erases its inputs", async ({ page }) => {
    await signInAsAarohi(page);
    await page.goto("/eligibility");
    await page.getByRole("region", { name: "Your check" }).getByRole("link").click();
    await page.getByRole("button", { name: "Close this check" }).click();
    await expect(page).toHaveURL(/\/eligibility\?closed=1$/);
    await expect(page.getByText("Check closed. Its financial inputs have been erased.")).toBeVisible();
    await expect(page.getByRole("region", { name: "Past checks" })).toContainText("Closed");
  });

  test("the consent appears in the consent centre", async ({ page }) => {
    await signInAsAarohi(page);
    await page.goto("/account/consents");
    await expect(
      page.getByRole("region", { name: "Optional" }).getByRole("link", { name: /Financial eligibility/ }),
    ).toContainText("On");
  });
});
