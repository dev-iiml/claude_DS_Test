export const ACTOR_TYPES = ["user", "system"] as const;
export type ActorType = (typeof ACTOR_TYPES)[number];
