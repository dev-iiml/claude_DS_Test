import type { BureauScoreBand, FinancePurpose, IncomeSource } from "./domain";
import type { FinFeatureKey } from "./financial-features";

/**
 * Creator-facing copy for the eligibility check (pure; safe in native apps).
 * Describes inputs — never an approval, limit or "score you deserve".
 */
export const PURPOSE_LABELS: Record<FinancePurpose, string> = {
  equipment: "Camera, studio or tech equipment",
  content_production: "Content production or travel for a shoot",
  working_capital: "Working capital between brand payments",
  marketing: "Growing my channel or brand",
  education: "Courses or professional development",
  other: "Something else",
};

export const INCOME_SOURCE_LABELS: Record<IncomeSource, string> = {
  brand_deals: "Brand deals",
  platform_payouts: "Platform payouts",
  affiliate: "Affiliate commissions",
  services: "Services or freelance",
  products: "My own products",
  other: "Other",
};

export const BUREAU_BAND_LABELS: Record<BureauScoreBand, string> = {
  no_hit: "No credit history found",
  thin: "Limited credit history",
  low: "Developing",
  medium: "Fair",
  high: "Strong",
};

export const FIN_FEATURE_COPY: Record<FinFeatureKey, { label: string; group: "credit" | "cashflow" | "declared" }> = {
  bureau_score_band: { label: "Credit history", group: "credit" },
  active_credit_accounts: { label: "Active credit accounts", group: "credit" },
  delinquencies_12m: { label: "Missed payments (12 months)", group: "credit" },
  credit_enquiries_6m: { label: "Recent credit enquiries (6 months)", group: "credit" },
  avg_monthly_inflow_6m: { label: "Average money in each month", group: "cashflow" },
  inflow_volatility_6m: { label: "Month-to-month variation", group: "cashflow" },
  avg_monthly_creator_income_6m: { label: "Average creator income each month", group: "cashflow" },
  creator_income_share_6m: { label: "Share of money in from creator work", group: "cashflow" },
  creator_income_months_12m: { label: "Months with creator income", group: "cashflow" },
  avg_monthly_net_cashflow_6m: { label: "Average left over each month", group: "cashflow" },
  declared_monthly_income: { label: "Monthly income you told us", group: "declared" },
  declared_to_observed_income: { label: "Told vs seen in bank data", group: "declared" },
  declared_monthly_emi: { label: "Existing EMIs you told us", group: "declared" },
  emi_to_income: { label: "EMIs as a share of income", group: "declared" },
  income_source_count: { label: "Income sources", group: "declared" },
};

const inr = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
export const formatInr = (n: number) => inr.format(n);

export function formatFinValue(key: FinFeatureKey, value: number | string | null): string {
  if (value === null) return "Not available";
  if (typeof value === "string")
    return key === "bureau_score_band" ? (BUREAU_BAND_LABELS[value as BureauScoreBand] ?? value) : value;
  switch (key) {
    case "avg_monthly_inflow_6m":
    case "avg_monthly_creator_income_6m":
    case "avg_monthly_net_cashflow_6m":
    case "declared_monthly_income":
    case "declared_monthly_emi":
      return formatInr(value);
    case "creator_income_share_6m":
    case "creator_income_months_12m":
    case "emi_to_income":
      return `${Math.round(value * 100)}%`;
    case "inflow_volatility_6m":
      return value < 0.15 ? "Steady" : value < 0.35 ? "Some variation" : "Varies a lot";
    case "declared_to_observed_income":
      return value >= 0.8 && value <= 1.25 ? "Matches" : value > 1.25 ? "Higher than seen" : "Lower than seen";
    default:
      return String(value);
  }
}
