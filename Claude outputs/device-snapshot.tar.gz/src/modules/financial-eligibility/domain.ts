/**
 * Financial-eligibility vocabulary (regulated financial domain).
 *
 * The check is product-agnostic: the creator says what the money is for and
 * roughly how much; the partner bank/NBFC decides the product later.
 */
export const APPLICATION_STATUSES = [
  "draft",
  "inputs_ready",
  /** Sent to a partner lender (Stage 12). Its inputs then follow the lender's retention rules. */
  "submitted",
  "withdrawn",
  "expired",
] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];
export const OPEN_APPLICATION_STATUSES = ["draft", "inputs_ready"] as const satisfies readonly ApplicationStatus[];

export const FINANCE_PURPOSES = [
  "equipment",
  "content_production",
  "working_capital",
  "marketing",
  "education",
  "other",
] as const;
export type FinancePurpose = (typeof FINANCE_PURPOSES)[number];

export const INCOME_SOURCES = [
  "brand_deals",
  "platform_payouts",
  "affiliate",
  "services",
  "products",
  "other",
] as const;
export type IncomeSource = (typeof INCOME_SOURCES)[number];

export const BUREAU_STATUSES = ["not_started", "completed"] as const;
export const CASHFLOW_STATUSES = ["not_started", "pending", "completed", "declined", "skipped"] as const;
export type CashflowStatus = (typeof CASHFLOW_STATUSES)[number];

export const BUREAU_SCORE_BANDS = ["no_hit", "thin", "low", "medium", "high"] as const;
export type BureauScoreBand = (typeof BUREAU_SCORE_BANDS)[number];

/** Unsent applications expire, and their financial inputs are erased, after this many days (user decision). */
export const APPLICATION_TTL_DAYS = 90;
/** Bureau checks per creator per rolling 30 days. */
export const BUREAU_CHECKS_PER_30_DAYS = 3;
/** Months of bank cashflow requested through the Account Aggregator. */
export const CASHFLOW_MONTHS = 12;

export const AMOUNT_LIMITS = { min: 10_000, max: 25_00_000 } as const;
export const MONTHLY_INCOME_MAX = 1_00_00_000;
