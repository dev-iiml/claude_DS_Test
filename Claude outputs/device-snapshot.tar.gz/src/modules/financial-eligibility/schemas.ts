import { z } from "zod";

import { AMOUNT_LIMITS, FINANCE_PURPOSES, INCOME_SOURCES, MONTHLY_INCOME_MAX } from "./domain";

/** "1,50,000" / "150000" / "₹ 1.5L" is not accepted — digits and separators only. */
const rupees = (label: string, { min, max }: { min: number; max: number }) =>
  z
    .string({ error: `Enter ${label}.` })
    .trim()
    .transform((v) => v.replace(/[,\s₹]/g, ""))
    .pipe(
      z
        .string()
        .regex(/^\d{1,9}$/, `Enter ${label} in rupees, using digits only.`)
        .transform(Number)
        .pipe(
          z
            .number()
            .min(min, `${label[0]!.toUpperCase()}${label.slice(1)} must be at least ₹${min.toLocaleString("en-IN")}.`)
            .max(max, `${label[0]!.toUpperCase()}${label.slice(1)} must be at most ₹${max.toLocaleString("en-IN")}.`),
        ),
    );

export const applicationDetailsSchema = z.object({
  purpose: z.enum(FINANCE_PURPOSES, { error: "Choose what it's for." }),
  requestedAmount: rupees("an amount", AMOUNT_LIMITS),
  declaredMonthlyIncome: rupees("your average monthly income", { min: 0, max: MONTHLY_INCOME_MAX }),
  declaredMonthlyEmi: rupees("your existing monthly EMIs (0 if none)", { min: 0, max: MONTHLY_INCOME_MAX }),
  incomeSources: z
    .array(z.enum(INCOME_SOURCES))
    .min(1, "Choose at least one income source.")
    .transform((v) => [...new Set(v)]),
});
export type ApplicationDetailsInput = z.output<typeof applicationDetailsSchema>;

/**
 * Personal PAN only (4th character `P`) — Cohort A0 applies as an individual.
 * Used once for the bureau call; never stored, logged or echoed back.
 */
export const panSchema = z
  .string({ error: "Enter your PAN." })
  .trim()
  .toUpperCase()
  .regex(/^[A-Z]{5}[0-9]{4}[A-Z]$/, "Enter a valid PAN, like ABCPE1234F.")
  .refine((v) => v[3] === "P", "Enter your personal PAN (the 4th character is P).");
