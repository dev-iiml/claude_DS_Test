import { and, eq, inArray, isNull, lte, ne, sql } from "drizzle-orm";

import {
  bureauSummaries,
  cashflowMonths,
  creditApplications,
  financialFeatureRuns,
  financialFeatures,
} from "@/db/schema";
import type { DbExecutor } from "@/db/types";
import { eraseUnderwritingRuns } from "@/modules/underwriting/erasure";

/**
 * Erases the financial inputs of a creator's applications (all, or one, or
 * those created up to `before`). Applications sent to a lender are never
 * touched here — they follow the lender's retention rules (retention hold).
 * The application row stays as a tombstone with its status and timestamps.
 * Must run inside a transaction (feature rows are append-only otherwise).
 */
export async function eraseFinancialInputs(
  tx: DbExecutor,
  input: { userId: string; applicationId?: string; before?: Date; now: Date },
): Promise<Record<string, number>> {
  const apps = await tx
    .select({ id: creditApplications.id })
    .from(creditApplications)
    .where(
      and(
        eq(creditApplications.userId, input.userId),
        ne(creditApplications.status, "submitted"),
        isNull(creditApplications.inputsErasedAt),
        input.applicationId ? eq(creditApplications.id, input.applicationId) : undefined,
        input.before ? lte(creditApplications.createdAt, input.before) : undefined,
      ),
    );
  if (!apps.length) return { applications: 0 };
  const ids = apps.map((a) => a.id);

  const bureau = await tx
    .delete(bureauSummaries)
    .where(inArray(bureauSummaries.applicationId, ids))
    .returning({ id: bureauSummaries.applicationId });
  const months = await tx
    .delete(cashflowMonths)
    .where(inArray(cashflowMonths.applicationId, ids))
    .returning({ id: cashflowMonths.applicationId });
  await tx.execute(sql`set local creatorco.erasure = 'on'`);
  const features = await tx
    .delete(financialFeatures)
    .where(inArray(financialFeatures.applicationId, ids))
    .returning({ id: financialFeatures.id });
  await tx.delete(financialFeatureRuns).where(inArray(financialFeatureRuns.applicationId, ids));
  await tx.execute(sql`set local creatorco.erasure = 'off'`);
  const underwriting = await eraseUnderwritingRuns(tx, { userId: input.userId, applicationIds: ids });
  await tx
    .update(creditApplications)
    .set({
      requestedAmount: null,
      declaredMonthlyIncome: null,
      declaredMonthlyEmi: null,
      incomeSources: [],
      panMasked: null,
      panFingerprint: null,
      cashflowReference: null,
      cashflowProvider: null,
      inputsErasedAt: input.now,
    })
    .where(inArray(creditApplications.id, ids));
  return {
    applications: ids.length,
    credit_summaries: bureau.length,
    cashflow_months: months.length,
    features: features.length,
    ...underwriting,
  };
}
