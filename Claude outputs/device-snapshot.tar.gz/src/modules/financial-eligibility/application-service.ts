import { and, asc, count, desc, eq, inArray, isNull, lte } from "drizzle-orm";

import type { Database } from "@/db/create-db";
import {
  bureauSummaries,
  cashflowMonths,
  creatorProfiles,
  creditApplications,
  financialFeatureRuns,
  financialFeatures,
} from "@/db/schema";
import type { DbExecutor } from "@/db/types";
import { callProvider, countRecentProviderCalls, recordAuditEvent } from "@/modules/audit";
import { CONSENT_KEYS, grantConsent, hasValidConsent } from "@/modules/consent";
import { sha256Hex } from "@/modules/identity/auth/tokens";
import { getIdentityPrefill } from "@/modules/identity/identity-prefill";
import type { CreditBureauProvider } from "@/providers/bureau/types";
import type { FinancialDataProvider } from "@/providers/financial-data/types";

import {
  APPLICATION_TTL_DAYS,
  BUREAU_CHECKS_PER_30_DAYS,
  CASHFLOW_MONTHS,
  OPEN_APPLICATION_STATUSES,
  type CashflowStatus,
} from "./domain";
import { eraseFinancialInputs } from "./erasure";
import {
  FIN_ENGINE_VERSION,
  computeFinancialFeatures,
  type FinFeatureKey,
  type FinancialEngineInput,
} from "./financial-features";
import { hashFinancialInputs } from "./inputs-hash";
import type { ApplicationDetailsInput } from "./schemas";
import { panFingerprint } from "./pan-fingerprint";

/**
 * Financial eligibility (Stage 09) — regulated financial domain. Collects
 * permitted inputs for one product-agnostic eligibility check and computes
 * Financial Capacity features. It never decides eligibility or a limit;
 * that is the underwriting engine's recommendation (Stage 10) and, finally,
 * the partner lender's decision.
 */

export class FinancialEligibilityError extends Error {
  constructor(
    readonly code:
      | "profile_inactive"
      | "consent_required"
      | "not_found"
      | "wrong_step"
      | "bureau_limit"
      | "pan_mismatch"
      | "provider_error"
      | "provider_changed",
    message?: string,
    /** The check concerned, when the caller can resume it. */
    readonly applicationId?: string,
  ) {
    super(message ?? code);
    this.name = "FinancialEligibilityError";
  }
}

export interface FinDeps {
  db: Database;
  now?: Date;
}

type Application = typeof creditApplications.$inferSelect;
const isOpen = (a: Application) => (OPEN_APPLICATION_STATUSES as readonly string[]).includes(a.status);
const BUREAU_OPERATION = "fetch_bureau_summary";

async function completedProfile(db: DbExecutor, userId: string) {
  const [p] = await db
    .select({ id: creatorProfiles.id, status: creatorProfiles.profileStatus })
    .from(creatorProfiles)
    .where(eq(creatorProfiles.userId, userId))
    .limit(1);
  if (!p || p.status !== "completed") throw new FinancialEligibilityError("profile_inactive");
  return p.id;
}

async function ownOpenApplication(db: DbExecutor, userId: string, applicationId: string) {
  const [app] = await db
    .select()
    .from(creditApplications)
    .where(and(eq(creditApplications.id, applicationId), eq(creditApplications.userId, userId)))
    .limit(1);
  if (!app) throw new FinancialEligibilityError("not_found");
  if (!isOpen(app)) throw new FinancialEligibilityError("wrong_step", "This check is closed.");
  return app;
}

async function audit(
  db: DbExecutor,
  userId: string,
  applicationId: string,
  eventType: string,
  metadata: Record<string, string | number | boolean> = {},
) {
  await recordAuditEvent(db, {
    actorType: "user",
    actorId: userId,
    eventType,
    entityType: "credit_application",
    entityId: applicationId,
    metadata,
  });
}

/** The creator's open check, if any (expiring stale ones first). */
export async function getOpenApplication(deps: FinDeps, userId: string): Promise<Application | null> {
  await expireStaleApplications(deps, { userId });
  const [app] = await deps.db
    .select()
    .from(creditApplications)
    .where(
      and(eq(creditApplications.userId, userId), inArray(creditApplications.status, [...OPEN_APPLICATION_STATUSES])),
    )
    .limit(1);
  return app ?? null;
}

/** Records the financial-eligibility consent and opens a check (or returns the open one). */
export async function startApplication(
  deps: FinDeps,
  input: { userId: string; consentDefinitionId: string; source: "settings" | "api" },
) {
  const now = deps.now ?? new Date();
  const creatorId = await completedProfile(deps.db, input.userId);
  const existing = await getOpenApplication(deps, input.userId);
  if (existing) {
    if (await hasValidConsent(deps.db, input.userId, CONSENT_KEYS.financialEligibility, now)) return existing;
    // The consent text changed while this check was open: record the new consent and carry on with the same check.
    return deps.db.transaction(async (tx) => {
      const receipt = await grantConsent(tx, {
        userId: input.userId,
        key: CONSENT_KEYS.financialEligibility,
        consentDefinitionId: input.consentDefinitionId,
        source: input.source,
        metadata: { surface: "eligibility_consent_renewed" },
        now,
      });
      const [app] = await tx
        .update(creditApplications)
        .set({ consentReceiptId: receipt.id })
        .where(eq(creditApplications.id, existing.id))
        .returning();
      await audit(tx, input.userId, existing.id, "financial_eligibility.consent_renewed");
      return app!;
    });
  }

  return deps.db.transaction(async (tx) => {
    const receipt = await grantConsent(tx, {
      userId: input.userId,
      key: CONSENT_KEYS.financialEligibility,
      consentDefinitionId: input.consentDefinitionId,
      source: input.source,
      metadata: { surface: "eligibility_start" },
      now,
    });
    const [app] = await tx
      .insert(creditApplications)
      .values({
        userId: input.userId,
        creatorId,
        consentReceiptId: receipt.id,
        expiresAt: new Date(now.getTime() + APPLICATION_TTL_DAYS * 86_400_000),
        createdAt: now,
      })
      .returning();
    await audit(tx, input.userId, app!.id, "financial_eligibility.started");
    return app!;
  });
}

async function requireConsent(db: DbExecutor, userId: string, now: Date) {
  if (!(await hasValidConsent(db, userId, CONSENT_KEYS.financialEligibility, now))) {
    throw new FinancialEligibilityError("consent_required");
  }
}

export async function saveApplicationDetails(
  deps: FinDeps,
  input: { userId: string; applicationId: string; details: ApplicationDetailsInput },
) {
  const now = deps.now ?? new Date();
  await completedProfile(deps.db, input.userId);
  await requireConsent(deps.db, input.userId, now);
  return deps.db.transaction(async (tx) => {
    await ownOpenApplication(tx, input.userId, input.applicationId);
    const [app] = await tx
      .update(creditApplications)
      .set({
        purpose: input.details.purpose,
        requestedAmount: input.details.requestedAmount,
        declaredMonthlyIncome: input.details.declaredMonthlyIncome,
        declaredMonthlyEmi: input.details.declaredMonthlyEmi,
        incomeSources: input.details.incomeSources,
        detailsCompletedAt: now,
      })
      .where(eq(creditApplications.id, input.applicationId))
      .returning();
    await audit(tx, input.userId, app!.id, "financial_eligibility.details_saved", { purpose: input.details.purpose });
    return finaliseIfComplete(tx, app!, now);
  });
}

/**
 * Bureau summary via the partner bureau. The PAN is used for this call and to
 * derive a masked PAN and a keyed fingerprint (duplicate checks); the PAN
 * itself is never stored, logged or returned. If the creator verified their
 * identity, the PAN must match the masked PAN on record.
 */
export async function runBureauCheck(
  deps: FinDeps & { bureau: CreditBureauProvider },
  input: { userId: string; applicationId: string; pan: string },
) {
  const now = deps.now ?? new Date();
  await completedProfile(deps.db, input.userId);
  await requireConsent(deps.db, input.userId, now);
  const app = await ownOpenApplication(deps.db, input.userId, input.applicationId);
  if (!app.detailsCompletedAt) throw new FinancialEligibilityError("wrong_step", "Add your details first.");

  const recent = await countRecentProviderCalls(deps.db, {
    userId: input.userId,
    operation: BUREAU_OPERATION,
    since: new Date(now.getTime() - 30 * 86_400_000),
  });
  if (recent >= BUREAU_CHECKS_PER_30_DAYS) {
    throw new FinancialEligibilityError(
      "bureau_limit",
      "You've reached the limit of credit checks for now. Please try again later.",
    );
  }

  const panMasked = `XXXXX${input.pan.slice(5)}`;
  // Derived before the bureau call, so a misconfigured secret fails before an enquiry is spent.
  const fingerprint = panFingerprint(input.pan);
  const verified = await getIdentityPrefill(deps.db, input.userId);
  if (verified && verified.panMasked !== panMasked) {
    throw new FinancialEligibilityError(
      "pan_mismatch",
      "This PAN doesn't match the one linked to your verified identity.",
    );
  }

  let summary;
  try {
    summary = await callProvider(
      deps.db,
      {
        userId: input.userId,
        provider: deps.bureau.descriptor,
        operation: BUREAU_OPERATION,
        consentReceiptId: app.consentReceiptId,
      },
      () => deps.bureau.fetchSummary({ subjectRef: input.pan, consentReceiptId: app.consentReceiptId }),
      (r) => ({ outcome: r.scoreBand === "no_hit" ? "not_found" : "success", reference: r.reference }),
    );
  } catch {
    throw new FinancialEligibilityError("provider_error", "The credit bureau didn't respond. Please try again.");
  }

  return deps.db.transaction(async (tx) => {
    const values = {
      provider: deps.bureau.descriptor.key,
      providerReference: summary.reference,
      scoreBand: summary.scoreBand,
      activeTradelines: summary.activeTradelines,
      delinquentTradelines12m: summary.delinquentTradelines12m,
      enquiries6m: summary.enquiries6m,
      retrievedAt: summary.retrievedAt,
    };
    await tx
      .insert(bureauSummaries)
      .values({ applicationId: app.id, ...values })
      .onConflictDoUpdate({ target: bureauSummaries.applicationId, set: values });
    const [updated] = await tx
      .update(creditApplications)
      .set({ panMasked, panFingerprint: fingerprint, bureauStatus: "completed" })
      .where(eq(creditApplications.id, app.id))
      .returning();
    await audit(tx, input.userId, app.id, "financial_eligibility.bureau_checked");
    return finaliseIfComplete(tx, updated!, now);
  });
}

/** Starts bank-data sharing at the Account Aggregator; returns where to send the creator. */
export async function startCashflowSharing(
  deps: FinDeps & { financialData: FinancialDataProvider },
  input: { userId: string; applicationId: string; redirectUri: string },
) {
  const now = deps.now ?? new Date();
  await completedProfile(deps.db, input.userId);
  await requireConsent(deps.db, input.userId, now);
  const app = await ownOpenApplication(deps.db, input.userId, input.applicationId);
  if (app.bureauStatus !== "completed")
    throw new FinancialEligibilityError("wrong_step", "Complete the credit check first.");
  if (app.status !== "draft")
    throw new FinancialEligibilityError("wrong_step", "Bank data is already settled for this check.");

  const { reference, redirectUrl } = await callProvider(
    deps.db,
    {
      userId: input.userId,
      provider: deps.financialData.descriptor,
      operation: "request_cashflow_consent",
      consentReceiptId: app.consentReceiptId,
    },
    () =>
      deps.financialData.requestConsent({
        // Pseudonymous subject: the aggregator never receives CreatorCo identifiers it doesn't need.
        subjectRef: sha256Hex(`cashflow:${input.userId}`).slice(0, 32),
        consentReceiptId: app.consentReceiptId,
        monthsRequested: CASHFLOW_MONTHS,
        redirectUri: input.redirectUri,
        asOf: now,
      }),
    (r) => ({ outcome: "success", reference: r.reference }),
  );
  await deps.db
    .update(creditApplications)
    .set({
      cashflowReference: reference,
      cashflowProvider: deps.financialData.descriptor.key,
      cashflowStatus: "pending",
    })
    .where(eq(creditApplications.id, app.id));
  await audit(deps.db, input.userId, app.id, "financial_eligibility.cashflow_requested");
  return { redirectUrl };
}

/** Return leg from the aggregator: approved → fetch monthly totals; declined → recorded. */
export async function completeCashflowSharing(
  deps: FinDeps & {
    financialData: FinancialDataProvider;
    /** The provider for a config key: completes sharing begun by a provider that is no longer primary. */
    financialDataFor?: (key: string) => Promise<FinancialDataProvider | null>;
  },
  input: { userId: string; reference: string; approved: boolean },
) {
  const now = deps.now ?? new Date();
  const [app] = await deps.db
    .select()
    .from(creditApplications)
    .where(and(eq(creditApplications.cashflowReference, input.reference), eq(creditApplications.userId, input.userId)))
    .limit(1);
  if (!app || !isOpen(app)) throw new FinancialEligibilityError("not_found");
  // Replayed or late callbacks don't change a settled step.
  if (app.cashflowStatus !== "pending") return app;
  await requireConsent(deps.db, input.userId, now);

  // The reference belongs to the provider that issued it; if ops has switched since, finish with that one,
  // or — when it can no longer serve — ask the creator to share again.
  let financialData = deps.financialData;
  if (app.cashflowProvider && app.cashflowProvider !== financialData.descriptor.key) {
    const pinned = deps.financialDataFor ? await deps.financialDataFor(app.cashflowProvider) : null;
    if (pinned) financialData = pinned;
  }
  if (app.cashflowProvider && app.cashflowProvider !== financialData.descriptor.key) {
    await deps.db
      .update(creditApplications)
      .set({ cashflowStatus: "not_started", cashflowReference: null, cashflowProvider: null })
      .where(
        and(
          eq(creditApplications.id, app.id),
          eq(creditApplications.cashflowStatus, "pending"),
          eq(creditApplications.cashflowReference, input.reference),
        ),
      );
    throw new FinancialEligibilityError(
      "provider_changed",
      "Bank data sharing was interrupted on our side. Please share it again.",
      app.id,
    );
  }

  if (!input.approved) {
    const [updated] = await deps.db
      .update(creditApplications)
      .set({ cashflowStatus: "declined" })
      .where(eq(creditApplications.id, app.id))
      .returning();
    await audit(deps.db, input.userId, app.id, "financial_eligibility.cashflow_declined");
    return deps.db.transaction((tx) => finaliseIfComplete(tx, updated!, now));
  }

  let summary;
  try {
    summary = await callProvider(
      deps.db,
      {
        userId: input.userId,
        provider: financialData.descriptor,
        operation: "fetch_cashflow_summary",
        consentReceiptId: app.consentReceiptId,
      },
      () => financialData.fetchSummary(input.reference),
      (r) => ({ outcome: r.monthly.length ? "success" : "not_found", reference: r.reference }),
    );
  } catch {
    throw new FinancialEligibilityError("provider_error", "We couldn't fetch your bank data. Please try again.");
  }

  return deps.db.transaction(async (tx) => {
    await tx.delete(cashflowMonths).where(eq(cashflowMonths.applicationId, app.id));
    if (summary.monthly.length) {
      await tx.insert(cashflowMonths).values(
        summary.monthly.map((m) => ({
          applicationId: app.id,
          month: `${m.month}-01`,
          inflowTotal: Math.round(m.inflowTotal),
          outflowTotal: Math.round(m.outflowTotal),
          creatorIncomeInflow: m.creatorIncomeInflow === null ? null : Math.round(m.creatorIncomeInflow),
        })),
      );
    }
    const [updated] = await tx
      .update(creditApplications)
      .set({ cashflowStatus: "completed" })
      .where(eq(creditApplications.id, app.id))
      .returning();
    await audit(tx, input.userId, app.id, "financial_eligibility.cashflow_received", {
      months: summary.monthly.length,
    });
    return finaliseIfComplete(tx, updated!, now);
  });
}

/** The creator can continue without bank data (underwriting will have less to go on). */
export async function skipCashflow(deps: FinDeps, input: { userId: string; applicationId: string }) {
  const now = deps.now ?? new Date();
  await requireConsent(deps.db, input.userId, now);
  return deps.db.transaction(async (tx) => {
    const app = await ownOpenApplication(tx, input.userId, input.applicationId);
    if (app.bureauStatus !== "completed")
      throw new FinancialEligibilityError("wrong_step", "Complete the credit check first.");
    if (app.status !== "draft") return app;
    const [updated] = await tx
      .update(creditApplications)
      .set({ cashflowStatus: "skipped" satisfies CashflowStatus })
      .where(eq(creditApplications.id, app.id))
      .returning();
    await audit(tx, input.userId, app.id, "financial_eligibility.cashflow_skipped");
    return finaliseIfComplete(tx, updated!, now);
  });
}

/** Closes a check at the creator's request and erases its inputs straight away. */
export async function closeApplication(deps: FinDeps, input: { userId: string; applicationId: string }) {
  const now = deps.now ?? new Date();
  return deps.db.transaction(async (tx) => {
    const app = await ownOpenApplication(tx, input.userId, input.applicationId);
    await tx
      .update(creditApplications)
      .set({ status: "withdrawn", closedAt: now })
      .where(eq(creditApplications.id, app.id));
    const erased = await eraseFinancialInputs(tx, { userId: input.userId, applicationId: app.id, now });
    await audit(tx, input.userId, app.id, "financial_eligibility.closed", erased);
  });
}

/** Closes every open check (used when the financial-eligibility consent is withdrawn). */
export async function closeOpenApplications(tx: DbExecutor, input: { userId: string; now: Date }) {
  const closed = await tx
    .update(creditApplications)
    .set({ status: "withdrawn", closedAt: input.now })
    .where(
      and(
        eq(creditApplications.userId, input.userId),
        inArray(creditApplications.status, [...OPEN_APPLICATION_STATUSES]),
      ),
    )
    .returning({ id: creditApplications.id });
  return closed.length;
}

/**
 * Unsent checks expire after APPLICATION_TTL_DAYS and their inputs are erased
 * (user decision). Runs lazily per creator and as a sweep for a scheduled job.
 */
export async function expireStaleApplications(deps: FinDeps, input: { userId?: string } = {}) {
  const now = deps.now ?? new Date();
  const stale = await deps.db
    .select({ id: creditApplications.id, userId: creditApplications.userId })
    .from(creditApplications)
    .where(
      and(
        inArray(creditApplications.status, [...OPEN_APPLICATION_STATUSES]),
        lte(creditApplications.expiresAt, now),
        input.userId ? eq(creditApplications.userId, input.userId) : undefined,
      ),
    );
  for (const app of stale) {
    await deps.db.transaction(async (tx) => {
      await tx
        .update(creditApplications)
        .set({ status: "expired", closedAt: now })
        .where(eq(creditApplications.id, app.id));
      const erased = await eraseFinancialInputs(tx, { userId: app.userId, applicationId: app.id, now });
      await recordAuditEvent(tx, {
        actorType: "system",
        eventType: "financial_eligibility.expired",
        entityType: "credit_application",
        entityId: app.id,
        metadata: erased,
      });
    });
  }
  return stale.length;
}

/** True while any check has been sent to a partner lender (drives retention holds). */
export async function hasApplicationsWithLender(db: DbExecutor, userId: string) {
  const rows = await db
    .select({ id: creditApplications.id })
    .from(creditApplications)
    .where(
      and(
        eq(creditApplications.userId, userId),
        eq(creditApplications.status, "submitted"),
        isNull(creditApplications.inputsErasedAt),
      ),
    )
    .limit(1);
  return rows.length > 0;
}

// ---------------------------------------------------------------------------
// Financial Capacity
// ---------------------------------------------------------------------------

export async function loadFinancialEngineInput(
  db: DbExecutor,
  app: Application,
  asOf: string,
): Promise<FinancialEngineInput> {
  const [bureau] = await db.select().from(bureauSummaries).where(eq(bureauSummaries.applicationId, app.id)).limit(1);
  const months = await db
    .select()
    .from(cashflowMonths)
    .where(eq(cashflowMonths.applicationId, app.id))
    .orderBy(asc(cashflowMonths.month));
  return {
    asOf,
    declared: {
      monthlyIncome: app.declaredMonthlyIncome ?? 0,
      monthlyEmi: app.declaredMonthlyEmi ?? 0,
      incomeSources: app.incomeSources,
    },
    bureau: bureau
      ? {
          scoreBand: bureau.scoreBand,
          activeTradelines: bureau.activeTradelines,
          delinquentTradelines12m: bureau.delinquentTradelines12m,
          enquiries6m: bureau.enquiries6m,
        }
      : null,
    cashflow: months.map((m) => ({
      month: m.month.slice(0, 7),
      inflow: m.inflowTotal,
      outflow: m.outflowTotal,
      creatorIncome: m.creatorIncomeInflow,
    })),
  };
}

async function finaliseIfComplete(tx: DbExecutor, app: Application, now: Date) {
  const ready =
    app.detailsCompletedAt !== null &&
    app.bureauStatus === "completed" &&
    // A declined share waits for the creator to retry or to continue without bank data.
    (["completed", "skipped"] as string[]).includes(app.cashflowStatus);
  if (!ready) return app;

  const engineInput = await loadFinancialEngineInput(tx, app, now.toISOString().slice(0, 10));
  const inputsHash = hashFinancialInputs(engineInput);
  const [existing] = await tx
    .select({ id: financialFeatureRuns.id })
    .from(financialFeatureRuns)
    .where(
      and(
        eq(financialFeatureRuns.applicationId, app.id),
        eq(financialFeatureRuns.engineVersion, FIN_ENGINE_VERSION),
        eq(financialFeatureRuns.inputsHash, inputsHash),
      ),
    )
    .limit(1);
  if (!existing) {
    const [run] = await tx
      .insert(financialFeatureRuns)
      .values({ applicationId: app.id, engineVersion: FIN_ENGINE_VERSION, inputsHash, computedAt: now })
      .returning({ id: financialFeatureRuns.id });
    await tx.insert(financialFeatures).values(
      computeFinancialFeatures(engineInput).map((f) => ({
        runId: run!.id,
        applicationId: app.id,
        featureKey: f.key,
        featureVersion: f.version,
        valueNumeric: typeof f.value === "number" ? String(f.value) : null,
        valueText: typeof f.value === "string" ? f.value : null,
        unit: f.unit,
        source: f.source,
        completeness: String(f.completeness),
        confidence: f.confidence,
        provenance: f.provenance,
      })),
    );
  }
  if (app.status === "inputs_ready") return app;
  const [updated] = await tx
    .update(creditApplications)
    .set({ status: "inputs_ready", inputsReadyAt: now })
    .where(eq(creditApplications.id, app.id))
    .returning();
  await recordAuditEvent(tx, {
    actorType: "system",
    eventType: "financial_eligibility.inputs_ready",
    entityType: "credit_application",
    entityId: app.id,
    metadata: { engine_version: FIN_ENGINE_VERSION, cashflow: app.cashflowStatus },
  });
  return updated!;
}

export interface StoredFinFeature {
  key: FinFeatureKey;
  value: number | string | null;
  unit: string;
  source: string;
  confidence: string;
  completeness: number;
}

/** Latest Financial Capacity run for an application the user owns. */
export async function getFinancialCapacity(db: DbExecutor, input: { userId: string; applicationId: string }) {
  const [run] = await db
    .select({
      id: financialFeatureRuns.id,
      engineVersion: financialFeatureRuns.engineVersion,
      computedAt: financialFeatureRuns.computedAt,
    })
    .from(financialFeatureRuns)
    .innerJoin(creditApplications, eq(creditApplications.id, financialFeatureRuns.applicationId))
    .where(
      and(eq(financialFeatureRuns.applicationId, input.applicationId), eq(creditApplications.userId, input.userId)),
    )
    .orderBy(desc(financialFeatureRuns.computedAt), desc(financialFeatureRuns.createdAt))
    .limit(1);
  if (!run) return null;
  const rows = await db.select().from(financialFeatures).where(eq(financialFeatures.runId, run.id));
  const features: StoredFinFeature[] = rows.map((r) => ({
    key: r.featureKey as FinFeatureKey,
    value: r.valueText ?? (r.valueNumeric === null ? null : Number(r.valueNumeric)),
    unit: r.unit,
    source: r.source,
    confidence: r.confidence,
    completeness: Number(r.completeness),
  }));
  return { runId: run.id, engineVersion: run.engineVersion, computedAt: run.computedAt, features };
}

/** An application the user owns (any status), for display. No PAN beyond the masked form. */
export async function getApplication(db: DbExecutor, input: { userId: string; applicationId: string }) {
  const [app] = await db
    .select()
    .from(creditApplications)
    .where(and(eq(creditApplications.id, input.applicationId), eq(creditApplications.userId, input.userId)))
    .limit(1);
  if (!app) return null;
  const [bureau] = await db
    .select({ scoreBand: bureauSummaries.scoreBand })
    .from(bureauSummaries)
    .where(eq(bureauSummaries.applicationId, app.id))
    .limit(1);
  const months = await db
    .select({ month: cashflowMonths.month })
    .from(cashflowMonths)
    .where(eq(cashflowMonths.applicationId, app.id));
  return { ...app, bureauScoreBand: bureau?.scoreBand ?? null, cashflowMonthsCount: months.length };
}

/** The creator's checks, newest first (status and dates only). */
export async function listApplications(db: DbExecutor, userId: string) {
  return db
    .select({
      id: creditApplications.id,
      status: creditApplications.status,
      purpose: creditApplications.purpose,
      createdAt: creditApplications.createdAt,
      closedAt: creditApplications.closedAt,
      expiresAt: creditApplications.expiresAt,
      inputsErasedAt: creditApplications.inputsErasedAt,
    })
    .from(creditApplications)
    .where(eq(creditApplications.userId, userId))
    .orderBy(desc(creditApplications.createdAt));
}

/** Aggregate counts for the risk console (no applicant data). */
export async function countApplicationsByStatus(db: DbExecutor) {
  return db
    .select({ status: creditApplications.status, n: count() })
    .from(creditApplications)
    .groupBy(creditApplications.status);
}
