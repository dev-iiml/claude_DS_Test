import { CONSENT_KEYS } from "./domain";

/**
 * Canonical consent texts, published to `consent_definitions` by
 * `npm run db:reference`. To change wording, add a NEW version here — never
 * edit a published one (the database rejects edits).
 *
 * DRAFT wording for the pilot. Must be reviewed by counsel before real users.
 */
export const CONSENT_DEFINITION_SEEDS = [
  {
    id: "00000000-0000-4000-8000-00000000c001",
    key: CONSENT_KEYS.creatorProfile,
    version: 1,
    title: "Creator Profile",
    purpose: "To create and maintain your CreatorCo Creator Professional Profile and show it to you inside CreatorCo.",
    body: [
      "CreatorCo will use the details you provide during onboarding — your name, display name, location, languages, creator handle, category, platforms you use, business and GST status, and professional interests — to create your Creator Professional Profile.",
      "This consent covers your profile only. It does not cover connecting social accounts, professional analytics, brand matching, checking financial eligibility or sharing information with any financial partner. CreatorCo will ask for each of those separately.",
      "You can withdraw this consent later. Withdrawing it will pause your Creator Professional Profile.",
    ].join("\n\n"),
    activeFrom: new Date("2026-09-01T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c002",
    key: CONSENT_KEYS.identityPrefill,
    version: 1,
    title: "Identity prefill",
    purpose:
      "To fetch the name and PAN-linked details registered to your verified mobile number from a verification partner, so we can prefill your legal name and find your GST registrations.",
    body: [
      "With your permission, CreatorCo will ask a verification partner for the name and PAN linked to the mobile number you just verified. We use the result to prefill your legal name — you can still edit it — and, if you choose, to find GST registrations linked to that PAN.",
      "CreatorCo stores only a masked form of your PAN (for example XXXXX1234X) and the name returned. Your full PAN is used only while the lookup runs and is not stored.",
      "This consent does not cover checking financial eligibility or sharing information with any financial partner. You can withdraw it later.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-01T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c003",
    key: CONSENT_KEYS.socialAccountConnection,
    version: 1,
    title: "Connect a creator account",
    purpose:
      "To connect a social account you choose and read its public profile and performance metrics, so your Creator Passport can show verified activity.",
    body: [
      "When you connect an account, CreatorCo receives — through a connection partner — the account's identifier, handle, creation date and performance metrics such as followers, views, engagement and posting activity. We don't receive your password and we can't post on your behalf.",
      "We store monthly metric snapshots for connected accounts. We don't store the content of your posts or personal data about your followers.",
      "You can disconnect an account at any time. This consent doesn't cover checking financial eligibility or sharing information with financial partners.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-01T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c004",
    key: CONSENT_KEYS.professionalAnalytics,
    version: 1,
    title: "Professional analytics",
    purpose:
      "To analyse your connected-account data and profile into professional signals (such as longevity, consistency and platform mix) shown on your Creator Passport.",
    body: [
      "CreatorCo will compute professional signals from your profile and connected-account metrics — for example how long you've been creating, how consistently you post and how your audience is spread across platforms. Each signal shows where it came from.",
      "These signals describe your creator business. They are not a credit score, and sharing them with any financial partner requires a separate consent.",
      "You can turn professional analytics off at any time.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-01T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c005",
    key: CONSENT_KEYS.financialEligibility,
    version: 1,
    title: "Financial eligibility check",
    purpose:
      "To check your eligibility for creator business finance from partner banks and NBFCs, using a credit bureau summary, summarised bank cashflow you choose to share, and what you tell us.",
    body: [
      "CreatorCo will use your PAN once to request a credit bureau summary through a partner. We keep only the summary — a score band and counts of accounts, recent missed payments and recent enquiries — and a masked PAN (for example XXXXX1234X). We do not store the full report or your full PAN.",
      "If you approve it on the Account Aggregator screen, we receive monthly totals of money in and out of your bank account for up to 12 months — not individual transactions. We also use the income, income sources, existing EMIs, purpose and amount you tell us.",
      "We use this to work out your Financial Capacity and, later, a CreatorCo recommendation. CreatorCo is not a lender: any finance is offered by a regulated partner and is subject to its approval. Nothing is sent to a lender without a separate consent from you.",
      "A check that is not sent to a lender expires after 90 days and its financial inputs are erased. You can withdraw this consent at any time; once a check has been sent to a lender, erasure follows that lender's legal retention requirements.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-01T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c006",
    key: CONSENT_KEYS.financialEligibility,
    version: 2,
    title: "Financial eligibility check",
    purpose:
      "To check your eligibility for creator business finance from partner banks and NBFCs, using a credit bureau summary, summarised bank cashflow you choose to share, what you tell us, and your Creator Professional Profile.",
    body: [
      "CreatorCo will use your PAN once to request a credit bureau summary through a partner. We keep only the summary — a score band and counts of accounts, recent missed payments and recent enquiries — and a masked PAN (for example XXXXX1234X). We do not store the full report or your full PAN.",
      "If you approve it on the Account Aggregator screen, we receive monthly totals of money in and out of your bank account for up to 12 months — not individual transactions. We also use the income, income sources, existing EMIs, purpose and amount you tell us.",
      "To prepare a CreatorCo recommendation we combine these financial inputs with your Creator Professional Profile and, if you have turned them on, your professional signals (such as how long you've been creating and how consistently you post). We also prepare a recommendation from financial information alone, to understand what your creator business adds. A copy of the inputs used is kept with the check so the recommendation can be explained and reproduced.",
      "CreatorCo is not a lender: any finance is offered by a regulated partner and is subject to its approval. Nothing is sent to a lender without a separate consent from you.",
      "A check that is not sent to a lender expires after 90 days and its financial inputs and recommendation are erased. You can withdraw this consent at any time; once a check has been sent to a lender, erasure follows that lender's legal retention requirements.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-02T00:00:00.000Z"),
  },
  {
    id: "00000000-0000-4000-8000-00000000c007",
    key: CONSENT_KEYS.financialEligibility,
    version: 3,
    title: "Financial eligibility check",
    purpose:
      "To check your eligibility for creator business finance from partner banks and NBFCs, using a credit bureau summary, summarised bank cashflow you choose to share, what you tell us, and your Creator Professional Profile — including checks that protect you and our partners from fraud.",
    body: [
      "CreatorCo will use your PAN once to request a credit bureau summary through a partner. We keep only the summary — a score band and counts of accounts, recent missed payments and recent enquiries — a masked PAN (for example XXXXX1234X) and a one-way, keyed fingerprint of your PAN used only for the fraud checks below. We do not store the full report or your full PAN.",
      "If you approve it on the Account Aggregator screen, we receive monthly totals of money in and out of your bank account for up to 12 months — not individual transactions. We also use the income, income sources, existing EMIs, purpose and amount you tell us.",
      "To prepare a CreatorCo recommendation we combine these financial inputs with your Creator Professional Profile and, if you have turned them on, your professional signals (such as how long you've been creating and how consistently you post). We also prepare a recommendation from financial information alone, to understand what your creator business adds. A copy of the inputs used is kept with the check so the recommendation can be explained and reproduced.",
      "To protect creators and partners from fraud, we also check the application for inconsistencies — for example whether your name matches your verified identity, whether the same PAN is used on another CreatorCo account, whether your declared income matches your bank data, and whether your connected accounts match what you declared. These checks never decide on their own: anything flagged is reviewed, and a partner lender makes any decision.",
      "CreatorCo is not a lender: any finance is offered by a regulated partner and is subject to its approval. Nothing is sent to a lender without a separate consent from you.",
      "A check that is not sent to a lender expires after 90 days and its financial inputs, fraud-check results and recommendation are erased. You can withdraw this consent at any time; once a check has been sent to a lender, erasure follows that lender's legal retention requirements.",
    ].join("\n\n"),
    activeFrom: new Date("2026-10-02T12:00:00.000Z"),
  },
] as const;

/** The newest seeded version of a purpose (what a creator is asked to agree to now). */
export function currentDefinitionSeed(key: string) {
  const seeds = CONSENT_DEFINITION_SEEDS.filter((d) => d.key === key);
  return [...seeds].sort((a, b) => b.version - a.version)[0];
}
