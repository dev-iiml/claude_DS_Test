import type { DbExecutor } from "@/db/types";
import type { ErasureScope } from "@/modules/consent/domain";
import { hasApplicationsWithLender } from "@/modules/financial-eligibility/application-service";

/**
 * Retention holds defer erasure (never processing stops). Reason codes only —
 * no details of the credit relationship leave the lending domain.
 */
export const RETENTION_HOLD_REASONS = [
  "credit_application_in_progress",
  "credit_facility_active",
  "regulatory_record_retention",
] as const;
export type RetentionHoldReason = (typeof RETENTION_HOLD_REASONS)[number];

export interface RetentionHoldChecker {
  holdsFor(db: DbExecutor, input: { userId: string; scope: ErasureScope }): Promise<RetentionHoldReason[]>;
}

/** Holds nothing (tests and tools). */
export const noRetentionHolds: RetentionHoldChecker = {
  async holdsFor() {
    return [];
  },
};

/**
 * Default checker: financial inputs of a check that has been sent to a partner
 * lender are held (the lender's retention rules apply). Creator-professional
 * data is not a lender record — underwriting snapshots its features into the
 * financial domain (Stage 10). Which records a lender actually needs, and for
 * how long, is for the partner and counsel to confirm.
 */
export const lendingRetentionHolds: RetentionHoldChecker = {
  async holdsFor(db, { userId, scope }) {
    if (scope !== "financial_inputs") return [];
    return (await hasApplicationsWithLender(db, userId)) ? ["credit_application_in_progress"] : [];
  },
};
