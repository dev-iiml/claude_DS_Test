/**
 * Background job vocabulary and pure policy. Jobs carry identifiers and
 * counts only — never personal or financial payloads.
 */
export const JOB_TYPES = ["expire_stale_applications", "process_deferred_erasures", "provider_health_check"] as const;
export type JobType = (typeof JOB_TYPES)[number];

/** A failed attempt goes back to `queued` with a later `run_after`; after the last attempt it is `dead`. */
export const JOB_STATUSES = ["queued", "running", "succeeded", "dead"] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];

export const DEFAULT_MAX_ATTEMPTS = 5;
/** A running job whose worker vanished (serverless timeout) is re-queued after this. */
export const STALE_LOCK_MS = 15 * 60_000;

export interface JobSchedule {
  type: JobType;
  label: string;
  description: string;
  everyMinutes: number;
}

export const JOB_SCHEDULES: readonly JobSchedule[] = [
  {
    type: "expire_stale_applications",
    label: "Expire stale eligibility checks",
    description: "Closes checks not sent to a lender within 90 days and erases their inputs.",
    everyMinutes: 60,
  },
  {
    type: "process_deferred_erasures",
    label: "Complete deferred erasures",
    description: "Erases data whose retention hold has ended.",
    everyMinutes: 60,
  },
  {
    type: "provider_health_check",
    label: "Provider health checks",
    description: "Checks every enabled provider configuration.",
    everyMinutes: 5,
  },
];

/** Exponential backoff: 30s, 1m, 2m, 4m … capped at 1h. */
export function retryDelayMs(attempt: number): number {
  return Math.min(30_000 * 2 ** Math.max(0, attempt - 1), 3_600_000);
}

/** Dedupe key for a schedule's current window, so overlapping ticks enqueue once. */
export function scheduleWindowKey(schedule: JobSchedule, now: Date): string {
  const windowMs = schedule.everyMinutes * 60_000;
  const start = new Date(Math.floor(now.getTime() / windowMs) * windowMs);
  return `${schedule.type}:${start.toISOString()}`;
}

/**
 * Error text kept on a job: class and a short message, never a payload. Query
 * errors are reduced to the database's own message (their text carries
 * parameters).
 */
export function describeJobError(error: unknown): string {
  if (!(error instanceof Error)) return "Unknown error";
  const root = error.message.startsWith("Failed query") && error.cause instanceof Error ? error.cause : error;
  const message = root.message.split(/\bparams:/)[0] ?? "";
  return `${root.name}: ${message}`.replace(/\s+/g, " ").trim().slice(0, 300);
}
