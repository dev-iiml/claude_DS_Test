import { expireStaleApplications } from "@/modules/financial-eligibility/application-service";
import { expireStaleChanges, runHealthChecks } from "@/modules/integrations";
import { processDeferredErasures } from "@/modules/privacy";

import type { JobHandlers } from "./runner";

/**
 * What each job type does. Handlers are idempotent sweeps over the owning
 * domain's services, so a retry never double-applies anything, and return
 * counts only.
 */
export const JOB_HANDLERS: JobHandlers = {
  expire_stale_applications: async ({ db, now }) => ({ expired: await expireStaleApplications({ db, now }) }),
  process_deferred_erasures: async ({ db, now }) => processDeferredErasures({ db, now }),
  provider_health_check: async ({ db, now }) => {
    const health = await runHealthChecks({ db, now, production: process.env.APP_ENV === "production" });
    return { ...health, expired_changes: await expireStaleChanges({ db, now }) };
  },
};
