import "server-only";

import type { getApplication } from "@/modules/financial-eligibility/application-service";

type App = NonNullable<Awaited<ReturnType<typeof getApplication>>>;

/** API shape of an application: no opaque provider references. */
export function applicationJson(app: App) {
  return {
    id: app.id,
    status: app.status,
    purpose: app.purpose,
    requestedAmount: app.requestedAmount,
    declaredMonthlyIncome: app.declaredMonthlyIncome,
    declaredMonthlyEmi: app.declaredMonthlyEmi,
    incomeSources: app.incomeSources,
    panMasked: app.panMasked,
    steps: {
      details: app.detailsCompletedAt ? "completed" : "not_started",
      creditCheck: app.bureauStatus,
      bank: app.cashflowStatus,
    },
    bureauScoreBand: app.bureauScoreBand,
    cashflowMonths: app.cashflowMonthsCount,
    expiresAt: app.expiresAt,
    inputsReadyAt: app.inputsReadyAt,
    closedAt: app.closedAt,
    inputsErasedAt: app.inputsErasedAt,
    createdAt: app.createdAt,
  };
}
