import "server-only";

import { FinancialEligibilityError } from "@/modules/financial-eligibility/application-service";

import { toApiError } from "../_lib/errors";
import { ApiError } from "../_lib/http";

const STATUS: Record<FinancialEligibilityError["code"], number> = {
  profile_inactive: 409,
  consent_required: 409,
  not_found: 404,
  wrong_step: 409,
  bureau_limit: 429,
  pan_mismatch: 422,
  provider_error: 502,
  provider_changed: 409,
};

export function toEligibilityApiError(error: unknown): never {
  if (error instanceof ApiError) throw error;
  if (error instanceof FinancialEligibilityError) {
    throw new ApiError(
      STATUS[error.code],
      error.code,
      error.message !== error.code ? error.message : "This step can't be completed right now.",
    );
  }
  toApiError(error);
}
