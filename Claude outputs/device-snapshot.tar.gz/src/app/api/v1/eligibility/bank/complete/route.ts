import { z } from "zod";

import { getDb } from "@/db";
import { underwriteIfReady } from "@/app/eligibility/_lib/underwrite";
import { completeCashflowSharing, getApplication } from "@/modules/financial-eligibility/application-service";
import { getProviderByKey, getProviders } from "@/modules/integrations/registry";

import { requireApiCreator } from "../../../_lib/auth";
import { json, readJson, route } from "../../../_lib/http";
import { toEligibilityApiError } from "../../_errors";
import { applicationJson } from "../../_view";

/** Completes Account Aggregator sharing with the reference and outcome from the redirect. */
export const POST = route("eligibility.bank_complete", async (request) => {
  const user = await requireApiCreator(request);
  const input = await readJson(request, z.object({ reference: z.string().min(4).max(160), approved: z.boolean() }));
  try {
    const db = getDb();
    const app = await completeCashflowSharing(
      {
        db,
        financialData: (await getProviders()).financialData,
        financialDataFor: (key) => getProviderByKey("financial_data", key),
      },
      { userId: user.userId, ...input },
    );
    await underwriteIfReady(user.userId, app);
    return json(applicationJson((await getApplication(db, { userId: user.userId, applicationId: app.id }))!));
  } catch (error) {
    toEligibilityApiError(error);
  }
});
