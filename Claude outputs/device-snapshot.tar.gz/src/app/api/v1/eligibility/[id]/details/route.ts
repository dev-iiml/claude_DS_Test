import { z } from "zod";

import { getDb } from "@/db";
import { underwriteIfReady } from "@/app/eligibility/_lib/underwrite";
import { getApplication, saveApplicationDetails } from "@/modules/financial-eligibility/application-service";
import { applicationDetailsSchema } from "@/modules/financial-eligibility/schemas";

import { requireApiCreator } from "../../../_lib/auth";
import { ApiError, json, readJson, route } from "../../../_lib/http";
import { toEligibilityApiError } from "../../_errors";
import { applicationJson } from "../../_view";

const amount = z.union([z.number().int().nonnegative(), z.string()]).transform(String);
const body = z
  .object({
    purpose: z.string(),
    requestedAmount: amount,
    declaredMonthlyIncome: amount,
    declaredMonthlyEmi: amount,
    incomeSources: z.array(z.string()),
  })
  .pipe(applicationDetailsSchema);

export const PUT = route<RouteContext<"/api/v1/eligibility/[id]/details">>(
  "eligibility.details",
  async (request, ctx) => {
    const user = await requireApiCreator(request);
    const { id } = await ctx.params;
    if (!z.uuid().safeParse(id).success) throw new ApiError(404, "not_found", "Check not found.");
    const details = await readJson(request, body);
    try {
      const db = getDb();
      const updated = await saveApplicationDetails({ db }, { userId: user.userId, applicationId: id, details });
      await underwriteIfReady(user.userId, updated);
      return json(applicationJson((await getApplication(db, { userId: user.userId, applicationId: id }))!));
    } catch (error) {
      toEligibilityApiError(error);
    }
  },
);
