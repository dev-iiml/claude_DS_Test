import { z } from "zod";

import { getDb } from "@/db";
import { getServerEnv } from "@/lib/env";
import { startCashflowSharing } from "@/modules/financial-eligibility/application-service";
import { getProviders } from "@/modules/integrations/registry";

import { BANK_CALLBACK_PATH } from "@/app/eligibility/_lib/constants";

import { requireApiCreator } from "../../../_lib/auth";
import { ApiError, json, route } from "../../../_lib/http";
import { toEligibilityApiError } from "../../_errors";

/** Starts Account Aggregator sharing; open `redirectUrl` in a system browser sheet. */
export const POST = route<RouteContext<"/api/v1/eligibility/[id]/bank">>(
  "eligibility.bank_start",
  async (request, ctx) => {
    const user = await requireApiCreator(request);
    const { id } = await ctx.params;
    if (!z.uuid().safeParse(id).success) throw new ApiError(404, "not_found", "Check not found.");
    try {
      const result = await startCashflowSharing(
        { db: getDb(), financialData: (await getProviders()).financialData },
        {
          userId: user.userId,
          applicationId: id,
          redirectUri: new URL(BANK_CALLBACK_PATH, getServerEnv().APP_URL).toString(),
        },
      );
      return json(result, 201);
    } catch (error) {
      toEligibilityApiError(error);
    }
  },
);
