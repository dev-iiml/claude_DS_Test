import { NextResponse, type NextRequest } from "next/server";

import { getServerEnv } from "@/lib/env";
import { requireCreator } from "@/modules/identity";
import { getProviders } from "@/modules/integrations/registry";

import { BANK_CALLBACK_PATH } from "@/app/eligibility/_lib/constants";

/** Mock aggregator decision: a plain form POST answered with a 303 to the callback (full navigation). */
export async function POST(request: NextRequest) {
  if ((await getProviders()).financialData.descriptor.mode !== "mock") return new NextResponse(null, { status: 404 });
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(getServerEnv().APP_URL).origin && origin !== request.nextUrl.origin) {
    return new NextResponse(null, { status: 403 });
  }
  await requireCreator();
  const form = await request.formData();
  const reference = typeof form.get("reference") === "string" ? (form.get("reference") as string) : "";
  const status = form.get("decision") === "approve" ? "approved" : "rejected";
  const url = new URL(BANK_CALLBACK_PATH, request.nextUrl.origin);
  url.search = new URLSearchParams({ reference, status }).toString();
  return NextResponse.redirect(url, 303);
}
