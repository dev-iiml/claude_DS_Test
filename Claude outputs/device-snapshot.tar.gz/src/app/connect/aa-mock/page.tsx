import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { Lede, PageHeading } from "@/components/creatorco";
import { Button } from "@/components/ui/button";
import { requireCreator } from "@/modules/identity";
import { getProviders } from "@/modules/integrations/registry";

export const metadata: Metadata = { title: "Test Account Aggregator" };

/** Stand-in for an Account Aggregator's consent screen (mock provider only). */
export default async function MockAggregatorPage({ searchParams }: PageProps<"/connect/aa-mock">) {
  if ((await getProviders()).financialData.descriptor.mode !== "mock") notFound();
  await requireCreator();
  const q = await searchParams;
  const reference = typeof q.reference === "string" ? q.reference : "";
  if (!/^aa_[a-z0-9_]{6,120}$/.test(reference)) notFound();

  return (
    <div className="flex min-h-dvh flex-col items-center bg-paper px-4 pt-safe pb-safe">
      <main id="main" className="flex w-full max-w-md flex-1 flex-col justify-center gap-6 py-10">
        <p className="self-center rounded-full bg-warning-soft px-3 py-1 text-[13px] font-medium text-warning">
          Test Account Aggregator — simulated
        </p>
        <div>
          <p className="text-[15px] text-ink-muted">Consent request from CreatorCo</p>
          <PageHeading className="mt-1">Share your bank account summary?</PageHeading>
          <Lede className="mt-2">
            Monthly totals for the last 12 months, for a financial eligibility check. One-time.
          </Lede>
        </div>
        <ul className="flex flex-col gap-2 rounded-[16px] bg-surface p-4 text-[15px] ring-1 ring-line ring-inset">
          <li>Account: Demo Bank savings ••••4821</li>
          <li>Data: monthly inflow and outflow totals</li>
          <li>Period: last 12 months · Frequency: once</li>
        </ul>
        <form action="/connect/aa-mock/approve" method="post" className="flex flex-col gap-3">
          <input type="hidden" name="reference" value={reference} />
          <Button type="submit" name="decision" value="approve" size="lg">
            Approve
          </Button>
          <Button type="submit" name="decision" value="reject" size="lg" variant="ghost">
            Reject
          </Button>
        </form>
        <Link href="/eligibility" className="self-center text-[13px] text-ink-subtle underline underline-offset-4">
          Back to CreatorCo
        </Link>
      </main>
    </div>
  );
}
