import type { Metadata } from "next";

import { FINANCE_PURPOSES, INCOME_SOURCES } from "@/modules/financial-eligibility/domain";
import { INCOME_SOURCE_LABELS, PURPOSE_LABELS } from "@/modules/financial-eligibility/presentation";

import { EligibilityFrame } from "../../_lib/frame";
import { loadApplicationStep } from "../../_lib/load";
import { DetailsForm } from "./details-form";

export const metadata: Metadata = { title: "Your details" };

export default async function DetailsPage({ params }: PageProps<"/eligibility/[id]/details">) {
  const { id } = await params;
  const { app } = await loadApplicationStep(id, "details");
  return (
    <EligibilityFrame
      step="details"
      title="Your details"
      description="Approximate figures are fine. We compare them with your bank data if you share it."
    >
      <DetailsForm
        applicationId={app.id}
        purposes={FINANCE_PURPOSES.map((p) => ({ value: p, label: PURPOSE_LABELS[p] }))}
        sources={INCOME_SOURCES.map((s) => ({ value: s, label: INCOME_SOURCE_LABELS[s] }))}
        saved={{
          purpose: app.purpose,
          requestedAmount: app.requestedAmount,
          declaredMonthlyIncome: app.declaredMonthlyIncome,
          declaredMonthlyEmi: app.declaredMonthlyEmi,
          incomeSources: app.incomeSources,
        }}
      />
    </EligibilityFrame>
  );
}
