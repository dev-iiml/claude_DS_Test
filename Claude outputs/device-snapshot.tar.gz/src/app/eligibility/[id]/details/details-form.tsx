"use client";

import { useActionState } from "react";

import { CheckboxChip, ChoiceFieldset, FormField, FormFooter, FormMessage, RadioRow } from "@/components/creatorco";
import { SubmitButton } from "@/components/creatorco/submit-button";
import { Input } from "@/components/ui/input";
import { initialFormState } from "@/lib/forms";

import { listValue, textValue } from "@/app/onboarding/_lib/form-values";

import { saveDetailsAction } from "../../actions";

interface Saved {
  purpose: string | null;
  requestedAmount: number | null;
  declaredMonthlyIncome: number | null;
  declaredMonthlyEmi: number | null;
  incomeSources: string[];
}

const fmt = (n: number | null) => (n === null ? null : n.toLocaleString("en-IN"));

function RupeeInput(props: React.ComponentProps<typeof Input>) {
  return (
    <div className="relative">
      <span
        aria-hidden="true"
        className="pointer-events-none absolute top-1/2 left-4 -translate-y-1/2 text-[17px] text-ink-muted"
      >
        ₹
      </span>
      <Input inputMode="numeric" autoComplete="off" className="pl-9 tabular-nums" {...props} />
    </div>
  );
}

export function DetailsForm({
  applicationId,
  purposes,
  sources,
  saved,
}: {
  applicationId: string;
  purposes: { value: string; label: string }[];
  sources: { value: string; label: string }[];
  saved: Saved;
}) {
  const [state, action] = useActionState(saveDetailsAction, initialFormState);
  const e = state.fieldErrors ?? {};
  const purpose = textValue(state, "purpose", saved.purpose);
  const chosen = listValue(state, "incomeSources", saved.incomeSources);

  return (
    <form action={action} className="flex flex-col gap-8" noValidate>
      <FormMessage state={state} />
      <input type="hidden" name="applicationId" value={applicationId} />

      <ChoiceFieldset id="purpose" legend="What is it for?" errors={e.purpose} required>
        {purposes.map((p) => (
          <RadioRow key={p.value} name="purpose" value={p.value} label={p.label} defaultChecked={purpose === p.value} />
        ))}
      </ChoiceFieldset>

      <FormField
        id="requestedAmount"
        label="Roughly how much?"
        description="Between ₹10,000 and ₹25,00,000."
        errors={e.requestedAmount}
        required
      >
        {(a11y) => (
          <RupeeInput
            {...a11y}
            name="requestedAmount"
            defaultValue={textValue(state, "requestedAmount", fmt(saved.requestedAmount))}
          />
        )}
      </FormField>

      <FormField
        id="declaredMonthlyIncome"
        label="Average monthly income"
        description="Your typical income from all sources over the last six months, before tax."
        errors={e.declaredMonthlyIncome}
        required
      >
        {(a11y) => (
          <RupeeInput
            {...a11y}
            name="declaredMonthlyIncome"
            defaultValue={textValue(state, "declaredMonthlyIncome", fmt(saved.declaredMonthlyIncome))}
          />
        )}
      </FormField>

      <ChoiceFieldset id="incomeSources" legend="Where does it come from?" errors={e.incomeSources} required>
        <div className="flex flex-wrap gap-2">
          {sources.map((s) => (
            <CheckboxChip
              key={s.value}
              name="incomeSources"
              value={s.value}
              label={s.label}
              defaultChecked={chosen.includes(s.value)}
            />
          ))}
        </div>
      </ChoiceFieldset>

      <FormField
        id="declaredMonthlyEmi"
        label="Existing monthly EMIs"
        description="Loan or card EMIs you already pay each month. Enter 0 if none."
        errors={e.declaredMonthlyEmi}
        required
      >
        {(a11y) => (
          <RupeeInput
            {...a11y}
            name="declaredMonthlyEmi"
            defaultValue={textValue(state, "declaredMonthlyEmi", fmt(saved.declaredMonthlyEmi))}
          />
        )}
      </FormField>

      <FormFooter>
        <SubmitButton size="lg">Save and continue</SubmitButton>
      </FormFooter>
    </form>
  );
}
