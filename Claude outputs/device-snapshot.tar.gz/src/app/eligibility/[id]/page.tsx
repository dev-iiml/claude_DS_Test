import Link from "next/link";
import type { Metadata } from "next";
import { redirect } from "next/navigation";

import { ListGroup, ListRow, StatusBadge } from "@/components/creatorco";
import { Button } from "@/components/ui/button";
import { getDb } from "@/db";
import { getFinancialCapacity } from "@/modules/financial-eligibility/application-service";
import { hasUnderwritingRun } from "@/modules/underwriting/underwriting-service";
import {
  FIN_FEATURE_COPY,
  PURPOSE_LABELS,
  formatFinValue,
  formatInr,
} from "@/modules/financial-eligibility/presentation";

import { closeCheckAction, prepareRecommendationAction } from "../actions";
import { EligibilityFrame } from "../_lib/frame";
import { loadApplicationStep } from "../_lib/load";
import { stepPath } from "../_lib/steps";

export const metadata: Metadata = { title: "Financial Capacity" };

const GROUPS = [
  { key: "credit", label: "Credit history", footer: "From a partner credit bureau summary." },
  { key: "cashflow", label: "Bank cashflow", footer: "Monthly totals shared through the Account Aggregator." },
  { key: "declared", label: "What you told us", footer: "Self-declared, compared with bank data where available." },
] as const;

const date = new Intl.DateTimeFormat("en-IN", {
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "Asia/Kolkata",
});

export default async function SummaryPage({ params }: PageProps<"/eligibility/[id]">) {
  const { id } = await params;
  const { user, app } = await loadApplicationStep(id, "summary");
  if (app.status === "draft") redirect(stepPath(app));
  const capacity = await getFinancialCapacity(getDb(), { userId: user.userId, applicationId: app.id });
  const open = app.status === "inputs_ready";
  const prepared = await hasUnderwritingRun(getDb(), app.id);

  return (
    <EligibilityFrame
      step="summary"
      title="Your Financial Capacity"
      description="The financial inputs a partner lender would look at. Your CreatorCo recommendation, which also weighs your creator business, comes next."
    >
      <div className="flex flex-col gap-8">
        <ListGroup
          id="request"
          label="Your request"
          action={
            open ? (
              <Link
                href={`/eligibility/${app.id}/details`}
                className="text-[15px] text-gold"
                aria-label="Edit your details"
              >
                Edit
              </Link>
            ) : null
          }
        >
          <ListRow label="For" value={app.purpose ? PURPOSE_LABELS[app.purpose] : "—"} />
          <ListRow label="Amount" value={app.requestedAmount !== null ? formatInr(app.requestedAmount) : "—"} />
          <ListRow
            label="Status"
            accessory={
              <StatusBadge tone={open ? "success" : "neutral"}>
                {open ? "Inputs ready" : app.status === "expired" ? "Expired" : "Closed"}
              </StatusBadge>
            }
          />
        </ListGroup>

        {capacity ? (
          GROUPS.map((g) => {
            const items = capacity.features.filter((f) => FIN_FEATURE_COPY[f.key]?.group === g.key);
            if (g.key === "cashflow" && items.every((f) => f.value === null)) {
              return (
                <ListGroup key={g.key} id={`fin-${g.key}`} label={g.label}>
                  <ListRow
                    label="No bank data shared"
                    detail="Your recommendation will rely more on what you told us."
                  />
                </ListGroup>
              );
            }
            return (
              <ListGroup key={g.key} id={`fin-${g.key}`} label={g.label} footer={g.footer}>
                {items.map((f) => (
                  <ListRow key={f.key} label={FIN_FEATURE_COPY[f.key].label} value={formatFinValue(f.key, f.value)} />
                ))}
              </ListGroup>
            );
          })
        ) : (
          <ListGroup id="erased" label="Financial inputs">
            <ListRow label="Erased" detail="This check's financial inputs are no longer held." />
          </ListGroup>
        )}

        <ListGroup id="next" label="What happens next">
          <ListRow
            label="CreatorCo recommendation"
            detail={
              prepared
                ? "Prepared from your Financial Capacity and your creator business. A partner lender reviews it under its own policy before any offer."
                : "Combines your Financial Capacity with your creator business. Subject to partner-lender approval."
            }
            accessory={
              <StatusBadge tone={prepared ? "success" : "neutral"}>
                {prepared ? "Prepared" : "Not prepared"}
              </StatusBadge>
            }
          />
          <ListRow
            label="Nothing is sent to a lender yet"
            detail="That needs a separate consent from you, asked for when a partner is ready."
          />
        </ListGroup>

        {open && !prepared && capacity ? (
          <form action={prepareRecommendationAction}>
            <input type="hidden" name="applicationId" value={app.id} />
            <Button type="submit" variant="secondary">
              Prepare recommendation
            </Button>
          </form>
        ) : null}

        {open ? (
          <form action={closeCheckAction} className="flex flex-col gap-2">
            <input type="hidden" name="applicationId" value={app.id} />
            <p className="px-1 text-[13px] leading-snug text-ink-subtle">
              This check expires on {date.format(app.expiresAt)} unless sent to a lender. Closing it now erases its
              financial inputs straight away.
            </p>
            <div>
              <Button type="submit" variant="ghost" className="text-danger">
                Close this check
              </Button>
            </div>
          </form>
        ) : null}
      </div>
    </EligibilityFrame>
  );
}
