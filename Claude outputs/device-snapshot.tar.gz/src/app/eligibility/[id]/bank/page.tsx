import type { Metadata } from "next";

import { ListGroup, ListRow } from "@/components/creatorco";
import { Alert } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

import { skipBankAction, startBankSharingAction } from "../../actions";
import { EligibilityFrame } from "../../_lib/frame";
import { loadApplicationStep } from "../../_lib/load";

export const metadata: Metadata = { title: "Bank data" };

export default async function BankPage({ params, searchParams }: PageProps<"/eligibility/[id]/bank">) {
  const { id } = await params;
  const q = await searchParams;
  const { app } = await loadApplicationStep(id, "bank");

  return (
    <EligibilityFrame
      step="bank"
      title="Bank data"
      description="Optional, and the strongest evidence of your creator income. You approve the sharing in a regulated Account Aggregator, not in CreatorCo."
    >
      <div className="flex flex-col gap-8">
        {app.cashflowStatus === "declined" ? (
          <Alert tone="neutral">
            You didn&rsquo;t approve sharing. You can try again or continue without bank data.
          </Alert>
        ) : null}
        {q.error === "provider_changed" ? (
          <Alert tone="neutral">Bank data sharing was interrupted on our side. Please share it again.</Alert>
        ) : q.error ? (
          <Alert tone="danger">We couldn&rsquo;t reach the Account Aggregator. Please try again.</Alert>
        ) : null}

        <ListGroup id="what" label="What we receive" footer="Your bank login is never shared with CreatorCo.">
          <ListRow label="Monthly totals of money in and out" detail="For the last 12 months." />
          <ListRow
            label="Which money in looks like creator income"
            detail="Brand and platform payments, where the bank data shows it."
          />
          <ListRow label={<span className="text-ink-muted">Not individual transactions</span>} />
        </ListGroup>

        <div className="flex flex-col gap-3 sm:flex-row">
          <form action={startBankSharingAction}>
            <input type="hidden" name="applicationId" value={app.id} />
            <Button type="submit" size="lg" className="w-full sm:w-auto">
              Share via Account Aggregator
            </Button>
          </form>
          <form action={skipBankAction}>
            <input type="hidden" name="applicationId" value={app.id} />
            <Button type="submit" size="lg" variant="ghost" className="w-full sm:w-auto">
              Continue without bank data
            </Button>
          </form>
        </div>
        <p className="px-1 text-[13px] leading-snug text-ink-subtle">
          Without bank data, a recommendation has less to go on and relies more on what you&rsquo;ve told us.
        </p>
      </div>
    </EligibilityFrame>
  );
}
