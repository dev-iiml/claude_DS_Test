import type { Metadata } from "next";

import { ListGroup, ListRow } from "@/components/creatorco";
import { getDb } from "@/db";
import { BUREAU_BAND_LABELS } from "@/modules/financial-eligibility/presentation";
import { getIdentityPrefill } from "@/modules/identity/identity-prefill";

import { EligibilityFrame } from "../../_lib/frame";
import { loadApplicationStep } from "../../_lib/load";
import { PanForm } from "./pan-form";

export const metadata: Metadata = { title: "Credit check" };

export default async function CreditCheckPage({ params }: PageProps<"/eligibility/[id]/credit-check">) {
  const { id } = await params;
  const { user, app } = await loadApplicationStep(id, "credit-check");
  const verified = await getIdentityPrefill(getDb(), user.userId);

  return (
    <EligibilityFrame
      step="credit-check"
      title="Credit check"
      description="A partner credit bureau tells us a summary of your credit history: a band, and counts of accounts, missed payments and recent enquiries."
    >
      {app.bureauStatus === "completed" && app.bureauScoreBand ? (
        <ListGroup
          id="done"
          label="Already checked"
          footer="Run it again only if something has changed."
          className="mb-8"
        >
          <ListRow
            label="Credit history"
            value={BUREAU_BAND_LABELS[app.bureauScoreBand]}
            detail={app.panMasked ? `PAN ${app.panMasked}` : undefined}
          />
        </ListGroup>
      ) : null}
      <PanForm applicationId={app.id} verifiedPanMasked={verified?.panMasked ?? null} />
    </EligibilityFrame>
  );
}
