import { redirect } from "next/navigation";
import type { NextRequest } from "next/server";

import { getDb } from "@/db";
import { describeError, logger } from "@/lib/logger";
import {
  FinancialEligibilityError,
  completeCashflowSharing,
} from "@/modules/financial-eligibility/application-service";
import { requireCreator } from "@/modules/identity";
import { getProviderByKey, getProviders } from "@/modules/integrations/registry";

import { underwriteIfReady } from "../../_lib/underwrite";

/**
 * Account Aggregator return leg. The reference must belong to one of this
 * creator's open checks. Query values are never logged.
 */
export async function GET(request: NextRequest) {
  const user = await requireCreator();
  const reference = request.nextUrl.searchParams.get("reference") ?? "";
  const approved = request.nextUrl.searchParams.get("status") === "approved";
  if (!reference || reference.length > 160) redirect("/eligibility");

  let next: string;
  try {
    const app = await completeCashflowSharing(
      {
        db: getDb(),
        financialData: (await getProviders()).financialData,
        financialDataFor: (key) => getProviderByKey("financial_data", key),
      },
      { userId: user.userId, reference, approved },
    );
    await underwriteIfReady(user.userId, app);
    next = app.status === "inputs_ready" ? `/eligibility/${app.id}` : `/eligibility/${app.id}/bank`;
  } catch (error) {
    if (error instanceof FinancialEligibilityError && error.code === "provider_changed" && error.applicationId) {
      redirect(`/eligibility/${error.applicationId}/bank?error=provider_changed`);
    }
    if (!(error instanceof FinancialEligibilityError))
      logger.error("eligibility.bank_callback_failed", describeError(error));
    redirect("/eligibility");
  }
  redirect(next);
}
