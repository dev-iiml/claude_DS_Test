"use server";

import { redirect } from "next/navigation";
import { z } from "zod";

import { getDb } from "@/db";
import { fieldErrorsFromZod, formError, readCheckbox, readList, readText, type FormState } from "@/lib/forms";
import { getServerEnv } from "@/lib/env";
import { describeError, logger } from "@/lib/logger";
import { ConsentError } from "@/modules/consent";
import {
  FinancialEligibilityError,
  closeApplication,
  runBureauCheck,
  saveApplicationDetails,
  skipCashflow,
  startApplication,
  startCashflowSharing,
} from "@/modules/financial-eligibility/application-service";
import { applicationDetailsSchema, panSchema } from "@/modules/financial-eligibility/schemas";
import { requireCreator } from "@/modules/identity";
import { getProviders } from "@/modules/integrations/registry";

import { BANK_CALLBACK_PATH } from "./_lib/constants";
import { stepPath } from "./_lib/steps";
import { underwriteIfReady } from "./_lib/underwrite";

/**
 * Thin eligibility actions. Amounts and the PAN are never logged; the PAN is
 * never echoed back in form state.
 */

const idSchema = z.uuid();

function fromError(error: unknown, values: FormState["values"] = {}): FormState {
  if (error instanceof FinancialEligibilityError) {
    if (error.code === "profile_inactive") redirect("/dashboard");
    if (error.code === "consent_required") redirect("/eligibility/start");
    if (error.code === "not_found") redirect("/eligibility");
    return formError(error.message !== error.code ? error.message : "Something isn't right. Please try again.", {
      values,
    });
  }
  if (error instanceof ConsentError)
    return formError("The consent text has been updated. Please review it and try again.");
  logger.error("eligibility.action_failed", describeError(error));
  return formError("We couldn't save this. Please try again.", { values });
}

export async function startEligibilityAction(_prev: FormState, form: FormData): Promise<FormState> {
  const user = await requireCreator();
  const definitionId = idSchema.safeParse(readText(form, "consentDefinitionId"));
  if (!definitionId.success) return formError("Please reload and try again.");
  if (!readCheckbox(form, "agree")) {
    return formError("Tick the box to give this consent.", {
      fieldErrors: { agree: ["Tick the box to give this consent."] },
    });
  }
  let next: string;
  try {
    const app = await startApplication(
      { db: getDb() },
      { userId: user.userId, consentDefinitionId: definitionId.data, source: "settings" },
    );
    next = stepPath(app);
  } catch (error) {
    return fromError(error);
  }
  redirect(next);
}

export async function saveDetailsAction(_prev: FormState, form: FormData): Promise<FormState> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  const values = {
    purpose: readText(form, "purpose") ?? "",
    requestedAmount: readText(form, "requestedAmount") ?? "",
    declaredMonthlyIncome: readText(form, "declaredMonthlyIncome") ?? "",
    declaredMonthlyEmi: readText(form, "declaredMonthlyEmi") ?? "",
    incomeSources: readList(form, "incomeSources"),
  };
  const parsed = applicationDetailsSchema.safeParse(values);
  if (!parsed.success) {
    return formError("Please check the highlighted fields.", { fieldErrors: fieldErrorsFromZod(parsed.error), values });
  }
  let next: string;
  try {
    const app = await saveApplicationDetails(
      { db: getDb() },
      { userId: user.userId, applicationId: applicationId.data, details: parsed.data },
    );
    await underwriteIfReady(user.userId, app);
    next = stepPath(app);
  } catch (error) {
    return fromError(error, values);
  }
  redirect(next);
}

export async function creditCheckAction(_prev: FormState, form: FormData): Promise<FormState> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  if (!readCheckbox(form, "confirm")) {
    return formError("Please confirm this is your PAN.", {
      fieldErrors: { confirm: ["Please confirm this is your PAN."] },
    });
  }
  const pan = panSchema.safeParse(readText(form, "pan"));
  if (!pan.success)
    return formError("Please check your PAN.", { fieldErrors: { pan: pan.error.issues.map((i) => i.message) } });
  let next: string;
  try {
    const app = await runBureauCheck(
      { db: getDb(), bureau: (await getProviders()).bureau },
      { userId: user.userId, applicationId: applicationId.data, pan: pan.data },
    );
    await underwriteIfReady(user.userId, app);
    next = stepPath(app);
  } catch (error) {
    return fromError(error);
  }
  redirect(next);
}

export async function startBankSharingAction(form: FormData): Promise<void> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  let url: string;
  try {
    const r = await startCashflowSharing(
      { db: getDb(), financialData: (await getProviders()).financialData },
      {
        userId: user.userId,
        applicationId: applicationId.data,
        redirectUri: new URL(BANK_CALLBACK_PATH, getServerEnv().APP_URL).toString(),
      },
    );
    url = r.redirectUrl;
  } catch (error) {
    if (!(error instanceof FinancialEligibilityError))
      logger.error("eligibility.bank_start_failed", describeError(error));
    redirect(`/eligibility/${applicationId.data}/bank?error=start_failed`);
  }
  redirect(url);
}

export async function skipBankAction(form: FormData): Promise<void> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  try {
    const app = await skipCashflow({ db: getDb() }, { userId: user.userId, applicationId: applicationId.data });
    await underwriteIfReady(user.userId, app);
  } catch (error) {
    if (!(error instanceof FinancialEligibilityError)) logger.error("eligibility.skip_failed", describeError(error));
    redirect("/eligibility");
  }
  redirect(`/eligibility/${applicationId.data}`);
}

export async function closeCheckAction(form: FormData): Promise<void> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  try {
    await closeApplication({ db: getDb() }, { userId: user.userId, applicationId: applicationId.data });
  } catch (error) {
    if (!(error instanceof FinancialEligibilityError)) logger.error("eligibility.close_failed", describeError(error));
  }
  redirect("/eligibility?closed=1");
}

/** Prepares the recommendation again (e.g. after creator signals changed). Idempotent. */
export async function prepareRecommendationAction(form: FormData): Promise<void> {
  const user = await requireCreator();
  const applicationId = idSchema.safeParse(readText(form, "applicationId"));
  if (!applicationId.success) redirect("/eligibility");
  await underwriteIfReady(user.userId, { id: applicationId.data, status: "inputs_ready" });
  redirect(`/eligibility/${applicationId.data}`);
}
