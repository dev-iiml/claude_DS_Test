import "server-only";

import { getDb } from "@/db";
import { describeError, logger } from "@/lib/logger";
import { runUnderwriting } from "@/modules/underwriting/underwriting-service";

/**
 * Prepares (or reuses) the CreatorCo recommendation once a check's inputs are
 * ready. Failures are logged and never block the creator's journey — the
 * recommendation can be prepared again later.
 */
export async function underwriteIfReady(userId: string, app: { id: string; status: string }) {
  if (app.status !== "inputs_ready") return;
  try {
    await runUnderwriting(getDb(), { userId, applicationId: app.id });
  } catch (error) {
    logger.error("underwriting.run_failed", describeError(error));
  }
}
