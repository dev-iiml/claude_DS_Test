import type { creditApplications } from "@/db/schema";

type App = Pick<
  typeof creditApplications.$inferSelect,
  "id" | "status" | "detailsCompletedAt" | "bureauStatus" | "cashflowStatus"
>;

export const ELIGIBILITY_STEPS = [
  { key: "consent", label: "Consent" },
  { key: "details", label: "Your details" },
  { key: "credit-check", label: "Credit check" },
  { key: "bank", label: "Bank data" },
  { key: "summary", label: "Financial Capacity" },
] as const;
export type EligibilityStep = (typeof ELIGIBILITY_STEPS)[number]["key"];

export function currentStep(app: App): EligibilityStep {
  if (app.status !== "draft") return "summary";
  if (!app.detailsCompletedAt) return "details";
  if (app.bureauStatus !== "completed") return "credit-check";
  return "bank";
}

export function stepPath(app: App, step: EligibilityStep = currentStep(app)): string {
  return step === "summary" ? `/eligibility/${app.id}` : `/eligibility/${app.id}/${step}`;
}

/** A step is reachable once every earlier step is done. */
export function canOpen(app: App, step: EligibilityStep): boolean {
  const order = ELIGIBILITY_STEPS.map((s) => s.key) as EligibilityStep[];
  return order.indexOf(step) <= order.indexOf(currentStep(app)) || app.status === "inputs_ready";
}
