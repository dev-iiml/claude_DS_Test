import { BackLink, PageHeader, ProgressSteps } from "@/components/creatorco";

import { CreatorShell } from "@/app/_components/creator-shell";

import { ELIGIBILITY_STEPS, type EligibilityStep } from "./steps";

export function EligibilityFrame({
  step,
  title,
  description,
  children,
}: {
  step: EligibilityStep;
  title: string;
  description?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <CreatorShell>
      <BackLink href="/eligibility" label="Financial eligibility" />
      <div className="max-w-2xl">
        <ProgressSteps
          steps={ELIGIBILITY_STEPS}
          currentKey={step}
          label="Eligibility check progress"
          className="mb-7"
        />
        <PageHeader title={title} description={description} />
        {children}
      </div>
    </CreatorShell>
  );
}
