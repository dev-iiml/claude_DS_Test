import { sql } from "drizzle-orm";
import {
  check,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgSchema,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

import {
  APPLICATION_STATUSES,
  BUREAU_SCORE_BANDS,
  BUREAU_STATUSES,
  CASHFLOW_STATUSES,
  FINANCE_PURPOSES,
} from "@/modules/financial-eligibility/domain";
import { FRAUD_CATEGORIES, FRAUD_OUTCOMES, FRAUD_SEVERITIES } from "@/modules/fraud/rules";
import { FEATURE_CONFIDENCE, FEATURE_SOURCES } from "@/modules/professional-graph/domain";

import { createdAt, sqlInList, updatedAt } from "./_shared";
import { consentReceipts } from "./consent";
import { creatorProfiles } from "./creator-profile";
import { users } from "./identity";

/**
 * `fin` schema — the regulated financial domain, physically separate from the
 * creator-professional tables so it can be granted, retained and audited on
 * its own terms. Only `src/modules/financial-eligibility` reads or writes it.
 *
 * Stored: derived summaries only (bureau score band and counts, monthly
 * cashflow totals, what the creator declared). Never raw bureau reports,
 * tradelines, bank transactions or a full PAN.
 */
export const fin = pgSchema("fin");

export const creditApplications = fin
  .table(
    "credit_applications",
    {
      id: uuid("id").primaryKey().defaultRandom(),
      userId: uuid("user_id")
        .notNull()
        .references(() => users.id, { onDelete: "restrict" }),
      creatorId: uuid("creator_id")
        .notNull()
        .references(() => creatorProfiles.id, { onDelete: "restrict" }),
      status: text("status", { enum: APPLICATION_STATUSES }).notNull().default("draft"),
      consentReceiptId: uuid("consent_receipt_id")
        .notNull()
        .references(() => consentReceipts.id, { onDelete: "restrict" }),
      purpose: text("purpose", { enum: FINANCE_PURPOSES }),
      /** INR, whole rupees. */
      requestedAmount: integer("requested_amount"),
      declaredMonthlyIncome: integer("declared_monthly_income"),
      declaredMonthlyEmi: integer("declared_monthly_emi"),
      incomeSources: text("income_sources")
        .array()
        .notNull()
        .default(sql`'{}'::text[]`),
      detailsCompletedAt: timestamp("details_completed_at", { withTimezone: true }),
      /** `XXXXX1234A` — the full PAN is used once for the bureau call and never stored. */
      panMasked: text("pan_masked"),
      /** `v1:` + HMAC-SHA256(PAN, server secret) — duplicate-identity detection only; not reversible without the secret. */
      panFingerprint: text("pan_fingerprint"),
      bureauStatus: text("bureau_status", { enum: BUREAU_STATUSES }).notNull().default("not_started"),
      cashflowStatus: text("cashflow_status", { enum: CASHFLOW_STATUSES }).notNull().default("not_started"),
      /** Opaque provider reference for the Account Aggregator consent (no personal data). */
      cashflowReference: text("cashflow_reference"),
      /** Config key of the provider that issued the reference (the return leg must use the same one). */
      cashflowProvider: text("cashflow_provider"),
      expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
      inputsReadyAt: timestamp("inputs_ready_at", { withTimezone: true }),
      closedAt: timestamp("closed_at", { withTimezone: true }),
      /** Set when declared and fetched inputs are erased (withdrawal, expiry, closure). */
      inputsErasedAt: timestamp("inputs_erased_at", { withTimezone: true }),
      createdAt: createdAt(),
      updatedAt: updatedAt(),
    },
    (t) => [
      index("credit_applications_user_idx").on(t.userId, t.createdAt.desc()),
      index("credit_applications_expiry_idx")
        .on(t.expiresAt)
        .where(sql`${t.status} in ('draft', 'inputs_ready')`),
      uniqueIndex("credit_applications_cashflow_reference_key").on(t.cashflowReference),
      // One open check per creator at a time.
      uniqueIndex("credit_applications_one_open_key")
        .on(t.userId)
        .where(sql`${t.status} in ('draft', 'inputs_ready')`),
      check("credit_applications_status_valid", sql`${t.status} in (${sqlInList(APPLICATION_STATUSES)})`),
      check(
        "credit_applications_purpose_valid",
        sql`${t.purpose} is null or ${t.purpose} in (${sqlInList(FINANCE_PURPOSES)})`,
      ),
      check("credit_applications_bureau_status_valid", sql`${t.bureauStatus} in (${sqlInList(BUREAU_STATUSES)})`),
      check("credit_applications_cashflow_status_valid", sql`${t.cashflowStatus} in (${sqlInList(CASHFLOW_STATUSES)})`),
      check(
        "credit_applications_amounts_valid",
        sql`(${t.requestedAmount} is null or ${t.requestedAmount} between 10000 and 2500000)
          and (${t.declaredMonthlyIncome} is null or ${t.declaredMonthlyIncome} between 0 and 10000000)
          and (${t.declaredMonthlyEmi} is null or ${t.declaredMonthlyEmi} between 0 and 10000000)`,
      ),
      check("credit_applications_sources_bound", sql`cardinality(${t.incomeSources}) <= 6`),
      check(
        "credit_applications_pan_fingerprint_format",
        sql`${t.panFingerprint} is null or ${t.panFingerprint} ~ '^v[0-9]+:[0-9a-f]{64}$'`,
      ),
      index("credit_applications_pan_fingerprint_idx").on(t.panFingerprint),
      check(
        "credit_applications_cashflow_provider_format",
        sql`${t.cashflowProvider} is null or ${t.cashflowProvider} ~ '^[a-z][a-z0-9_]{0,39}$'`,
      ),
      check(
        "credit_applications_pan_masked_format",
        sql`${t.panMasked} is null or ${t.panMasked} ~ '^X{5}[0-9]{4}[A-Z]$'`,
      ),
      check(
        "credit_applications_ready_is_whole",
        sql`${t.status} <> 'inputs_ready' or (
          ${t.detailsCompletedAt} is not null and ${t.bureauStatus} = 'completed'
          and ${t.cashflowStatus} in ('completed', 'declined', 'skipped') and ${t.inputsReadyAt} is not null)`,
      ),
      check(
        "credit_applications_closed_has_timestamp",
        sql`${t.status} not in ('withdrawn', 'expired') or ${t.closedAt} is not null`,
      ),
      check(
        "credit_applications_erased_is_empty",
        sql`${t.inputsErasedAt} is null or (
          ${t.requestedAmount} is null and ${t.declaredMonthlyIncome} is null and ${t.declaredMonthlyEmi} is null
          and cardinality(${t.incomeSources}) = 0 and ${t.panMasked} is null and ${t.cashflowReference} is null
          and ${t.panFingerprint} is null)`,
      ),
    ],
  )
  .enableRLS();

/** Derived bureau summary — never the report or tradelines. */
export const bureauSummaries = fin
  .table(
    "bureau_summaries",
    {
      applicationId: uuid("application_id")
        .primaryKey()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      provider: text("provider").notNull(),
      providerReference: text("provider_reference").notNull(),
      scoreBand: text("score_band", { enum: BUREAU_SCORE_BANDS }).notNull(),
      activeTradelines: integer("active_tradelines").notNull(),
      delinquentTradelines12m: integer("delinquent_tradelines_12m").notNull(),
      enquiries6m: integer("enquiries_6m").notNull(),
      retrievedAt: timestamp("retrieved_at", { withTimezone: true }).notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      check("bureau_summaries_band_valid", sql`${t.scoreBand} in (${sqlInList(BUREAU_SCORE_BANDS)})`),
      check(
        "bureau_summaries_counts_non_negative",
        sql`${t.activeTradelines} >= 0 and ${t.delinquentTradelines12m} >= 0 and ${t.enquiries6m} >= 0`,
      ),
    ],
  )
  .enableRLS();

/** Monthly cashflow totals from the Account Aggregator — never transactions. */
export const cashflowMonths = fin
  .table(
    "cashflow_months",
    {
      applicationId: uuid("application_id")
        .notNull()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      month: date("month", { mode: "string" }).notNull(),
      inflowTotal: integer("inflow_total").notNull(),
      outflowTotal: integer("outflow_total").notNull(),
      creatorIncomeInflow: integer("creator_income_inflow"),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("cashflow_months_application_month_key").on(t.applicationId, t.month),
      check("cashflow_months_first_of_month", sql`extract(day from ${t.month}) = 1`),
      check(
        "cashflow_months_non_negative",
        sql`${t.inflowTotal} >= 0 and ${t.outflowTotal} >= 0 and coalesce(${t.creatorIncomeInflow}, 0) >= 0`,
      ),
    ],
  )
  .enableRLS();

/** One Financial Capacity computation; identical inputs reuse the run (reproducibility). */
export const financialFeatureRuns = fin
  .table(
    "financial_feature_runs",
    {
      id: uuid("id").primaryKey().defaultRandom(),
      applicationId: uuid("application_id")
        .notNull()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      engineVersion: text("engine_version").notNull(),
      inputsHash: text("inputs_hash").notNull(),
      computedAt: timestamp("computed_at", { withTimezone: true }).notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("financial_feature_runs_identity_key").on(t.applicationId, t.engineVersion, t.inputsHash),
      check("financial_feature_runs_hash_format", sql`${t.inputsHash} ~ '^[0-9a-f]{64}$'`),
    ],
  )
  .enableRLS();

export const financialFeatures = fin
  .table(
    "financial_features",
    {
      id: uuid("id").primaryKey().defaultRandom(),
      runId: uuid("run_id")
        .notNull()
        .references(() => financialFeatureRuns.id, { onDelete: "cascade" }),
      applicationId: uuid("application_id")
        .notNull()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      featureKey: text("feature_key").notNull(),
      featureVersion: text("feature_version").notNull(),
      valueNumeric: numeric("value_numeric", { precision: 18, scale: 6 }),
      valueText: text("value_text"),
      unit: text("unit").notNull(),
      source: text("source", { enum: FEATURE_SOURCES }).notNull(),
      completeness: numeric("completeness", { precision: 4, scale: 3 }).notNull(),
      confidence: text("confidence", { enum: FEATURE_CONFIDENCE }).notNull(),
      provenance: jsonb("provenance").$type<Record<string, unknown>>().notNull().default({}),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("financial_features_run_key").on(t.runId, t.featureKey),
      check("financial_features_source_valid", sql`${t.source} in (${sqlInList(FEATURE_SOURCES)})`),
      check("financial_features_confidence_valid", sql`${t.confidence} in (${sqlInList(FEATURE_CONFIDENCE)})`),
      check("financial_features_single_value", sql`${t.valueNumeric} is null or ${t.valueText} is null`),
      check("financial_features_completeness_range", sql`${t.completeness} between 0 and 1`),
      check("financial_features_provenance_bounded", sql`pg_column_size(${t.provenance}) <= 2048`),
    ],
  )
  .enableRLS();

/**
 * One underwriting run (Stage 10): a frozen input snapshot scored by both
 * models. (application, model_version, inputs_hash) is unique, so identical
 * inputs reuse the run. Append-only; erased with the check's inputs.
 */
export const underwritingRuns = fin
  .table(
    "underwriting_runs",
    {
      id: uuid("id").primaryKey().defaultRandom(),
      applicationId: uuid("application_id")
        .notNull()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      modelVersion: text("model_version").notNull(),
      inputsHash: text("inputs_hash").notNull(),
      financialRunId: uuid("financial_run_id").notNull(),
      /** The Professional Graph run used, if creator signals were available. */
      professionalRunId: uuid("professional_run_id"),
      computedAt: timestamp("computed_at", { withTimezone: true }).notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("underwriting_runs_identity_key").on(t.applicationId, t.modelVersion, t.inputsHash),
      index("underwriting_runs_application_idx").on(t.applicationId, t.computedAt.desc()),
      check("underwriting_runs_hash_format", sql`${t.inputsHash} ~ '^[0-9a-f]{64}$'`),
    ],
  )
  .enableRLS();

/** The exact feature values a run used (copied, so the run survives later data changes). */
export const underwritingInputs = fin
  .table(
    "underwriting_inputs",
    {
      runId: uuid("run_id")
        .notNull()
        .references(() => underwritingRuns.id, { onDelete: "cascade" }),
      featureKey: text("feature_key").notNull(),
      /** `financial` (fin domain) or `professional` (Creator Professional Graph) or `application`. */
      origin: text("origin").notNull(),
      valueNumeric: numeric("value_numeric", { precision: 18, scale: 6 }),
      valueText: text("value_text"),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("underwriting_inputs_run_key").on(t.runId, t.featureKey),
      check("underwriting_inputs_origin_valid", sql`${t.origin} in ('financial', 'professional', 'application')`),
      check("underwriting_inputs_single_value", sql`${t.valueNumeric} is null or ${t.valueText} is null`),
    ],
  )
  .enableRLS();

export const underwritingResults = fin
  .table(
    "underwriting_results",
    {
      runId: uuid("run_id")
        .notNull()
        .references(() => underwritingRuns.id, { onDelete: "cascade" }),
      model: text("model").notNull(),
      score: numeric("score", { precision: 5, scale: 1 }),
      grade: text("grade"),
      completeness: numeric("completeness", { precision: 4, scale: 3 }).notNull(),
      confidence: text("confidence", { enum: FEATURE_CONFIDENCE }).notNull(),
      outcome: text("outcome").notNull(),
      incomeBasis: integer("income_basis"),
      incomeBasisSource: text("income_basis_source"),
      recommendedExposure: integer("recommended_exposure"),
      maxRecommendedExposure: integer("max_recommended_exposure"),
      recommendedTenorMonths: integer("recommended_tenor_months"),
      /** Component scores, e.g. { financial_strength: 72.5, brand_recurrence: null }. */
      components: jsonb("components").$type<Record<string, number | null>>().notNull(),
      reasonCodes: jsonb("reason_codes").$type<{ code: string; effect: string; component: string }[]>().notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("underwriting_results_run_model_key").on(t.runId, t.model),
      check("underwriting_results_model_valid", sql`${t.model} in ('traditional', 'creator_enhanced')`),
      check("underwriting_results_grade_valid", sql`${t.grade} is null or ${t.grade} in ('A', 'B', 'C', 'D', 'E')`),
      check("underwriting_results_outcome_valid", sql`${t.outcome} in ('recommend', 'refer', 'not_recommended')`),
      check("underwriting_results_score_range", sql`${t.score} is null or ${t.score} between 0 and 100`),
      check(
        "underwriting_results_bounded",
        sql`pg_column_size(${t.components}) <= 1024 and pg_column_size(${t.reasonCodes}) <= 4096`,
      ),
    ],
  )
  .enableRLS();

/**
 * Fraud / authenticity check for an underwriting run (Stage 11): a separate
 * layer, never a weighted score. Inputs are numbers/booleans only, so the
 * check is reproducible from this row. Append-only; erased with the run.
 */
export const fraudChecks = fin
  .table(
    "fraud_checks",
    {
      id: uuid("id").primaryKey().defaultRandom(),
      runId: uuid("run_id")
        .notNull()
        .references(() => underwritingRuns.id, { onDelete: "cascade" }),
      applicationId: uuid("application_id")
        .notNull()
        .references(() => creditApplications.id, { onDelete: "cascade" }),
      rulesVersion: text("rules_version").notNull(),
      outcome: text("outcome", { enum: FRAUD_OUTCOMES }).notNull(),
      highestSeverity: text("highest_severity", { enum: FRAUD_SEVERITIES }),
      inputs: jsonb("inputs").$type<Record<string, number | boolean | null>>().notNull(),
      /** Which checks ran: [{ code, status: passed | flagged | not_run }]. */
      checks: jsonb("checks").$type<{ code: string; status: string }[]>().notNull(),
      computedAt: timestamp("computed_at", { withTimezone: true }).notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("fraud_checks_run_key").on(t.runId),
      index("fraud_checks_application_idx").on(t.applicationId),
      check("fraud_checks_outcome_valid", sql`${t.outcome} in (${sqlInList(FRAUD_OUTCOMES)})`),
      check(
        "fraud_checks_severity_valid",
        sql`${t.highestSeverity} is null or ${t.highestSeverity} in (${sqlInList(FRAUD_SEVERITIES)})`,
      ),
      check(
        "fraud_checks_outcome_matches_severity",
        sql`(${t.outcome} = 'clear') = (${t.highestSeverity} is null) and (${t.outcome} = 'review') = (${t.highestSeverity} = 'high')`,
      ),
      check("fraud_checks_bounded", sql`pg_column_size(${t.inputs}) <= 1024 and pg_column_size(${t.checks}) <= 2048`),
    ],
  )
  .enableRLS();

export const fraudFlags = fin
  .table(
    "fraud_flags",
    {
      checkId: uuid("check_id")
        .notNull()
        .references(() => fraudChecks.id, { onDelete: "cascade" }),
      code: text("code").notNull(),
      category: text("category", { enum: FRAUD_CATEGORIES }).notNull(),
      severity: text("severity", { enum: FRAUD_SEVERITIES }).notNull(),
      /** Numbers/booleans that triggered the flag (e.g. { name_match: 0.3 }). Never names or identifiers. */
      evidence: jsonb("evidence").$type<Record<string, number | boolean | null>>().notNull(),
      createdAt: createdAt(),
    },
    (t) => [
      uniqueIndex("fraud_flags_check_code_key").on(t.checkId, t.code),
      index("fraud_flags_code_idx").on(t.code),
      check("fraud_flags_code_format", sql`${t.code} ~ '^[A-Z][A-Z0-9_]{2,63}$'`),
      check("fraud_flags_category_valid", sql`${t.category} in (${sqlInList(FRAUD_CATEGORIES)})`),
      check("fraud_flags_severity_valid", sql`${t.severity} in (${sqlInList(FRAUD_SEVERITIES)})`),
      check("fraud_flags_evidence_bounded", sql`pg_column_size(${t.evidence}) <= 512`),
    ],
  )
  .enableRLS();
