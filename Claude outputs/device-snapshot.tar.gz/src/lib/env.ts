import "server-only";

import { z } from "zod";

const booleanString = z
  .enum(["true", "false"])
  .default("true")
  .transform((v) => v === "true");

const serverEnvSchema = z.object({
  APP_ENV: z.enum(["development", "test", "staging", "production"]).default("development"),
  APP_URL: z.url().default("http://localhost:3000"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(50).default(5),
  DATABASE_PREPARE: booleanString,
  SESSION_TTL_HOURS: z.coerce
    .number()
    .int()
    .min(1)
    .max(24 * 30)
    .default(24 * 7),
  /** Bearer secret for the scheduled job tick (`/api/internal/cron/tick`). Unset → the endpoint is disabled. */
  CRON_SECRET: z.string().min(32, "CRON_SECRET must be at least 32 characters").optional(),
  /** Key for PAN fingerprints (duplicate-identity checks). Required outside development/test. */
  PAN_FINGERPRINT_SECRET: z.string().min(32, "PAN_FINGERPRINT_SECRET must be at least 32 characters").optional(),
});

export type ServerEnv = z.infer<typeof serverEnvSchema>;

/** Secrets that must exist once real data is involved (staging/production). */
function requiredOutsideDev(env: ServerEnv): string[] {
  if (env.APP_ENV === "development" || env.APP_ENV === "test") return [];
  return env.PAN_FINGERPRINT_SECRET ? [] : ["PAN_FINGERPRINT_SECRET"];
}

let cached: ServerEnv | undefined;

/** Validated server environment. Throws with field names (never values) when invalid. */
export function getServerEnv(): ServerEnv {
  if (cached) return cached;
  const parsed = serverEnvSchema.safeParse(process.env);
  if (!parsed.success) {
    const fields = parsed.error.issues.map((i) => i.path.join(".")).join(", ");
    throw new Error(`Invalid server environment: ${fields}`);
  }
  const missing = requiredOutsideDev(parsed.data);
  if (missing.length)
    throw new Error(`Invalid server environment: ${missing.join(", ")} required in ${parsed.data.APP_ENV}`);
  cached = parsed.data;
  return cached;
}

/** Secure cookies everywhere except local development and test. */
export function isSecureCookieEnv(env: ServerEnv = getServerEnv()): boolean {
  return env.APP_ENV !== "development" && env.APP_ENV !== "test";
}
