import type { Provider } from "../types";

/**
 * Financial data (e.g. via an Account Aggregator under an eligible FIU/RE).
 * Returns aggregated monthly totals only. Raw transactions are processed by
 * the provider/RE and are never returned to CreatorCo.
 */
export interface MonthlyCashflow {
  month: string; // YYYY-MM
  inflowTotal: number; // INR
  outflowTotal: number; // INR
  creatorIncomeInflow: number | null; // INR, where classifiable
}

export interface FinancialSummary {
  reference: string;
  monthsCovered: number;
  monthly: MonthlyCashflow[];
  retrievedAt: Date;
}

export interface FinancialDataProvider extends Provider {
  /** Starts the data-sharing consent at the aggregator; the creator approves there and is redirected back. */
  requestConsent(input: {
    subjectRef: string;
    consentReceiptId: string;
    monthsRequested: number;
    redirectUri: string;
    asOf: Date;
  }): Promise<{ reference: string; redirectUrl: string }>;
  fetchSummary(reference: string): Promise<FinancialSummary>;
}
