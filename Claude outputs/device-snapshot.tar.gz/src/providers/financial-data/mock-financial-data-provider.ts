import { ProviderError } from "../errors";
import { stableHash, type ProviderHealth } from "../types";
import type { FinancialDataProvider, FinancialSummary, MonthlyCashflow } from "./types";

/**
 * Deterministic mock Account Aggregator. Approval happens on CreatorCo's own
 * `/connect/aa-mock` screen. The reference encodes the subject hash, the
 * anchor month and months requested, so the same consent always yields the
 * same monthly totals (ending the month before the anchor).
 */
export class MockFinancialDataProvider implements FinancialDataProvider {
  readonly descriptor = { key: "mock", kind: "financial_data", mode: "mock" } as const;

  constructor(private readonly approvePath = "/connect/aa-mock") {}

  async health(): Promise<ProviderHealth> {
    return { status: "ok", checkedAt: new Date(0) };
  }

  async requestConsent(input: {
    subjectRef: string;
    consentReceiptId: string;
    monthsRequested: number;
    redirectUri: string;
    asOf: Date;
  }) {
    const anchor = `${input.asOf.getUTCFullYear()}${String(input.asOf.getUTCMonth() + 1).padStart(2, "0")}`;
    const nonce = stableHash(`${input.consentReceiptId}:${input.asOf.toISOString()}`).toString(36);
    const reference = `aa_${stableHash(input.subjectRef).toString(36)}_${nonce}_${anchor}_${input.monthsRequested}`;
    const q = new URLSearchParams({ reference, redirect_uri: input.redirectUri });
    return { reference, redirectUrl: `${this.approvePath}?${q.toString()}` };
  }

  async fetchSummary(reference: string): Promise<FinancialSummary> {
    const parts = reference.split("_");
    const [subject, , anchor, monthsRaw] = [parts[1] ?? "", parts[2], parts[3] ?? "", parts[4]];
    if (!/^[0-9]{6}$/.test(anchor)) throw new ProviderError("rejected", "unknown mock reference");
    const months = Math.min(24, Math.max(1, Number(monthsRaw) || 12));
    const h = stableHash(subject);
    const year = Number(anchor.slice(0, 4));
    const month0 = Number(anchor.slice(4)) - 1;
    const base = 40_000 + (h % 160_000);
    const creatorShare = 0.55 + (h % 40) / 100; // 55%–94%
    const volatile = h % 7 === 0;
    const monthly: MonthlyCashflow[] = Array.from({ length: months }, (_, i) => {
      const d = new Date(Date.UTC(year, month0 - months + i, 1));
      const wobble = (((h >> (i % 20)) % 41) - 20) / 100; // ±20%
      const inflow = Math.max(0, Math.round(base * (1 + (volatile ? wobble * 2.5 : wobble))));
      const quietMonth = (h + i) % 11 === 0;
      return {
        month: `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`,
        inflowTotal: inflow,
        outflowTotal: Math.round(inflow * (0.55 + ((h >> i) % 30) / 100)),
        creatorIncomeInflow: quietMonth ? 0 : Math.round(inflow * creatorShare),
      };
    });
    return { reference, monthsCovered: months, monthly, retrievedAt: new Date() };
  }
}
