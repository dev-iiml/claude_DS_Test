import type { Provider } from "../types";

/**
 * Regulated entity (bank/NBFC) integration. CreatorCo submits a recommendation;
 * the RE applies its approved credit policy and owns the sanction decision.
 */
export interface CreditProposal {
  proposalId: string;
  applicationRef: string;
  modelVersion: string;
  riskGrade: string;
  recommendedExposure: number; // INR
  maxRecommendedExposure: number; // INR
  recommendedTenorMonths: number | null;
  reasonCodes: string[];
}

export interface LenderDecision {
  proposalId: string;
  lenderReference: string;
  outcome: "approved" | "modified" | "declined" | "pending";
  approvedExposure: number | null; // INR
  decisionReasonCodes: string[];
  decidedAt: Date | null;
}

export interface LenderProvider extends Provider {
  submitProposal(proposal: CreditProposal): Promise<{ lenderReference: string }>;
  getDecision(lenderReference: string, proposal: CreditProposal): Promise<LenderDecision>;
}
