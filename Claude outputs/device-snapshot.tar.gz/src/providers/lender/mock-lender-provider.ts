import { stableHash, type ProviderHealth } from "../types";
import type { CreditProposal, LenderDecision, LenderProvider } from "./types";

/** Simulated RE: a fixed, transparent policy for demos. Clearly not a real lender. */
export class MockLenderProvider implements LenderProvider {
  readonly descriptor = { key: "mock_re", kind: "lender", mode: "mock" } as const;

  async health(): Promise<ProviderHealth> {
    return { status: "ok", checkedAt: new Date(0) };
  }

  async submitProposal(proposal: CreditProposal) {
    return { lenderReference: `re_${stableHash(proposal.proposalId).toString(36)}` };
  }

  async getDecision(lenderReference: string, proposal: CreditProposal): Promise<LenderDecision> {
    const decline = proposal.riskGrade === "E";
    const cap = 200_000;
    const modified = !decline && proposal.recommendedExposure > cap;
    return {
      proposalId: proposal.proposalId,
      lenderReference,
      outcome: decline ? "declined" : modified ? "modified" : "approved",
      approvedExposure: decline ? null : Math.min(proposal.recommendedExposure, cap),
      decisionReasonCodes: decline ? ["RE_POLICY_GRADE"] : modified ? ["RE_POLICY_EXPOSURE_CAP"] : [],
      decidedAt: new Date("2026-01-01T00:00:00Z"),
    };
  }
}
