# CreatorCo — repository notes for Claude

The authoritative product, architecture and regulatory context is the **CreatorCo Project Knowledge File**. It is kept
in the claude.ai Project "DS_Test" as `CLAUDE.md`. Place a copy at `docs/PROJECT_KNOWLEDGE.md` so the import below
loads it. Read it before any product, architecture, data, underwriting, regulatory or UX decision.

@docs/PROJECT_KNOWLEDGE.md
@AGENTS.md

## Build status

Stages 00–11 are complete: foundations, design system (mobile-first, iOS/macOS patterns, dark default), core schema,
self-managed auth and roles, Cohort A0 onboarding, Creator Passport, social connection (mock provider), the
Professional Graph feature engine, the consent centre (receipts, withdrawal, hold-aware erasure, paused membership),
financial eligibility (separate `fin` schema, Financial Capacity features), Underwriting Engine v0 (Traditional vs
Creator-Enhanced, reproducible runs), the integration control plane (`/ops`: config-driven provider routing,
circuit breaker/failover, kill switch, maker-checker approvals, Postgres job queue), the fraud/authenticity layer
(`fraud-0.1.0`, explicit flags, high → refer), plus API v1 for future native apps. Next: Stage 12 risk console +
lender proposal/simulated RE decision (with 10c partner API keys + signed webhooks).

## Implementation conventions (established in Stages 00–04)

- Domain logic lives in `src/modules/<domain>`. Routes in `src/app` are thin: authorise (`requireCreator` /
  `requireAdmin`), validate (Zod schema from the module), call the module service, then redirect.
- Services take a `db`/`tx` argument (`DbExecutor`), so tests can run them against a real database.
- Never trust a role from the client. Read it from `users.role` via `modules/identity/dal.ts`.
- Schema changes go in `src/db/schema/*` → `npm run db:generate` → review the SQL.
  - Triggers, grants and reference data go in a `drizzle-kit generate --custom` migration.
  - Never edit an applied migration.
- Evolving vocabularies use reference tables. Stable state sets use `text` + `CHECK`.
- Consent text changes mean a **new version** in `src/modules/consent/definitions.ts`. Published versions are immutable
  in the DB.
- Audit events go through `recordAuditEvent`. Metadata holds small scalars only, and sensitive keys are rejected.
- GSTIN is a restricted field (it embeds PAN). Never log it, audit it, echo it in form state or show it in admin views.
- Providers: depend on interfaces in `src/providers/*/types.ts` and obtain instances with `await getProviders()` from
  `@/modules/integrations/registry` (or `resolveProvider(deps, kind)` when you hold a `db`). Do not use vendor names
  in DB columns. A vendor adapter is added to `src/providers/catalog.ts` with its secret names and a **strict**
  settings schema; adapters throw `ProviderError("rejected" | "unavailable" | "timeout")` so the circuit breaker can
  tell a refused request from an outage. Which adapter serves traffic is configuration in `/ops`, never code.
- The `ops` schema holds control-plane config, runtime state, approvals and jobs — no creator or financial data and
  no secrets (env var names only, `INTEGRATION_*`). Config changes go through `proposeChange` (maker-checker).
- Background work is a job type in `modules/jobs` (idempotent handler returning counts; payloads hold ids only).
- Design tokens live in `src/design/tokens.ts`; run `npm run tokens` after changing them (never edit `tokens.css`).
- Pure modules (engine, presentation, rules, schemas, tokens) must not import Node/DOM/Next APIs, so native apps can
  reuse them. Hashing etc. lives in separate files.
- Every new user-facing capability gets a JSON route under `src/app/api/v1` (bearer sessions only) alongside the web UI.
- Choice controls stretch the native input over the row; in E2E use role-based `check()`, not text clicks.
- Withdrawal effects live in `modules/privacy/purposes.ts`; domain modules own their own erasure functions. New data
  tied to a consent purpose must be added to that purpose's erasure scope.
- Credit-related retention is expressed as a `RetentionHoldChecker`: holds defer erasure only; processing
  always stops at once.
- The `fin` schema is the regulated financial domain: only `modules/financial-eligibility` and `modules/underwriting`
  read or write it, and it
  holds derived summaries only (no full PAN, bureau reports or transactions; a keyed PAN fingerprint for duplicate checks). Never join it into professional tables.
- Underwriting weights/policy live in `modules/underwriting/model.ts`; any change bumps `UNDERWRITING_MODEL_VERSION`.
  Creators never see recommendation figures before a partner-lender review.
- Fraud rules live in `modules/fraud/rules.ts` (pure, numbers/booleans in, flags out); any change bumps
  `FRAUD_RULES_VERSION`. Fraud is never a weighted score; it only routes to `refer`. Fraud results and the keyed PAN
  fingerprint are stored by `modules/underwriting` / `modules/financial-eligibility` in `fin` and are never shown to
  creators.
- Before handing off, run `npm run check`, then `npm run build && npm run test:e2e`.
