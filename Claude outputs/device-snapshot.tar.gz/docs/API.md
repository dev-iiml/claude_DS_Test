# CreatorCo API v1

JSON API for future iOS and Android apps (and partner tooling). It exposes the same domain services as the web app;
routes are thin (authenticate → validate with the module's Zod schema → call the module service).

## Conventions

- Base path: `/api/v1`. Request bodies are `application/json` (max 16 KB).
- **Authentication: bearer tokens only.** `Authorization: Bearer <token>`. Cookies are ignored, so there is no CSRF
  surface. Tokens come from sign-up/sign-in with `client` = `ios` | `android` | `api`.
- Session channels are separated: a browser (`web`) session works only as a cookie; a native/API session works only
  as a bearer token.
- Success returns the resource (no wrapper). Errors return `{ "error": { "code", "message", "fields"? } }`.
- Every response is `Cache-Control: no-store`. Request/response bodies are never logged.

| Status | Meaning                                                                                                           |
| ------ | ----------------------------------------------------------------------------------------------------------------- |
| 401    | `unauthenticated` — missing/expired/revoked token                                                                 |
| 403    | `forbidden` (wrong role) · `inactive`                                                                             |
| 409    | state conflict: `step_locked`, `profile_incomplete`, `membership_paused`, `consent_outdated`, `provider_changed`… |
| 415    | body is not JSON                                                                                                  |
| 422    | `validation_failed` (with `fields`) or a domain rule                                                              |
| 429    | `locked` — too many sign-in attempts                                                                              |
| 503    | `service_unavailable` — a provider capability is paused (kill switch) or has no healthy route; retry later        |

`provider_changed` means ops switched the provider while a social or Account Aggregator flow was in progress: start
that flow again. Staff consoles (`/admin`, `/ops`) have no API; the only non-v1 route is the scheduler tick
`GET /api/internal/cron/tick` (`Authorization: Bearer $CRON_SECRET`, disabled when unset), which returns job counts.

## Endpoints

| Method & path                                           | Purpose                                                                                                                                                                                                                 |
| ------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `GET /health`                                           | Liveness + DB reachability                                                                                                                                                                                              |
| `POST /auth/sign-up`                                    | `{ email, password, confirmPassword, client }` → `201 { token, expiresAt, user }`                                                                                                                                       |
| `POST /auth/sign-in`                                    | `{ email, password, client }` → `{ token, expiresAt, user }`                                                                                                                                                            |
| `POST /auth/sign-out`                                   | Revokes the current token → `204`                                                                                                                                                                                       |
| `GET /me`                                               | `{ user, onboarding: { status, nextStep } }`                                                                                                                                                                            |
| `PUT /onboarding/{about\|profile\|business\|interests}` | Saves a section → `204`. Draft profiles follow step order; completed profiles edit the Passport                                                                                                                         |
| `POST /onboarding/complete`                             | `{ consentDefinitionId, agree: true }` → `204`                                                                                                                                                                          |
| `GET /consents/{key}`                                   | Current versioned text for a purpose + whether the user holds it                                                                                                                                                        |
| `GET /passport`                                         | Creator Passport read model (no GSTIN/PAN/full mobile; no credit figures)                                                                                                                                               |
| `POST /social/connections`                              | `{ platform, connectionConsentId, analyticsConsentId?, additional? }` → `201 { authorizationUrl }`. `additional: true` adds another account on a platform that already has a connected one (max 3; `422 account_limit`) |
| `POST /social/connections/complete`                     | `{ state, code }` from the provider redirect → `201 { accountId, platform, handle, snapshotsStored, graphComputed }`                                                                                                    |
| `DELETE /social/accounts/{id}`                          | Disconnect → `204`                                                                                                                                                                                                      |
| `POST /social/accounts/{id}/primary`                    | Make a connected account the primary one on its platform → `204`                                                                                                                                                        |
| `POST /social/refresh`                                  | Re-fetch connected accounts, recompute signals                                                                                                                                                                          |
| `GET /professional-graph`                               | `{ enabled, graph }` — signals only while the analytics consent is on                                                                                                                                                   |
| `POST /professional-graph`                              | `{ consentDefinitionId }` → turn signals on (separate consent)                                                                                                                                                          |
| `DELETE /professional-graph`                            | Turn signals off (withdraws the consent) → `204`                                                                                                                                                                        |

Section bodies use the same shapes as the module schemas in `src/modules/creator-profile/schemas.ts`, e.g.
`PUT /onboarding/about` → `{ legalName, displayName, state, city, cityOther?, languages: ["en"], languagesOther? }` and
`PUT /onboarding/profile` → `{ primaryCreatorHandle, categories, primaryCategory, creatorSince: "YYYY-MM", platforms:
["instagram"], platformHandles: { "instagram": "handle" } }`.

Mobile OTP, identity prefill and GST lookup endpoints are not exposed yet (they remain web server actions).

## Social connection from a native app

1. `GET /consents/social_account_connection` (and `professional_analytics` if offering signals) and show the text.
2. `POST /social/connections` → open `authorizationUrl` in `ASWebAuthenticationSession` / Custom Tabs.
3. The provider redirects to the registered callback with `state` and `code`; call
   `POST /social/connections/complete`.

With the **mock** provider, the authorisation screen (`/connect/mock`) needs a browser session, so tests build the
code directly: `base64url(JSON.stringify({ platform, handle, nonce }))` (see `e2e/api.spec.ts`). The redirect URI is
fixed to `${APP_URL}/passport/connect/callback` until native universal links are registered.
